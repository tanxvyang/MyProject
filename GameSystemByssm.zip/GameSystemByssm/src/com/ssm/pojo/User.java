package com.ssm.pojo;

import java.util.Date;
import java.text.SimpleDateFormat;

public class User {
	/**
	 * 
	USER_ID	NUMBER
	USER_NAME	VARCHAR2(20 BYTE)
	USER_PWD	VARCHAR2(20 BYTE)
	USER_PHONE	VARCHAR2(20 BYTE)
	USER_CITY	NUMBER
	USER_TARIFFE	NUMBER
	USER_CURRENCY	NUMBER
	USER_CARDAMOUNT	NUMBER
	USER_STATUS	NUMBER
	USERCREATE_TIME	DATE
	USER_SEX	NUMBER
	T_USER_BIRTHDAY	DATE
	 */
	
	private  Integer userId;
	private String userName;
	private String userPwd;
	private String userPhone;
	private String userCity;
	private Double userTariffe;	//话费
	private Integer userCurrency;//金币
	private Integer userCardamount;//游币
	private Integer userStatus;
	private Date userCreateTime;
	private Integer userSex;
	private String userBirthday;
	
	
	

	
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName
				+ ", userPwd=" + userPwd + ", userPhone=" + userPhone
				+ ", userCity=" + userCity + ", userTariffe=" + userTariffe
				+ ", userCurrency=" + userCurrency + ", userCardamount="
				+ userCardamount + ", userStatus=" + userStatus
				+ ", userCreateTime=" + userCreateTime + ", userSex=" + userSex
				+ ", userBirthday=" + userBirthday + "]";
	}

	public User(Integer userId, String userName, String userPwd,
			String userPhone, String userCity, Double userTariffe,
			Integer userCurrency, Integer userCardamount, Integer userStatus,
			Date userCreateTime, Integer userSex, String userBirthday) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPwd = userPwd;
		this.userPhone = userPhone;
		this.userCity = userCity;
		this.userTariffe = userTariffe;
		this.userCurrency = userCurrency;
		this.userCardamount = userCardamount;
		this.userStatus = userStatus;
		this.userCreateTime = userCreateTime;
		this.userSex = userSex;
		this.userBirthday = userBirthday;
	}

	public User() {
		super();
	}
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserCity() {
		return userCity;
	}
	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}
	public Double getUserTariffe() {
		return userTariffe;
	}
	public void setUserTariffe(Double userTariffe) {
		this.userTariffe = userTariffe;
	}
	public Integer getUserCurrency() {
		return userCurrency;
	}
	public void setUserCurrency(Integer userCurrency) {
		this.userCurrency = userCurrency;
	}
	public Integer getUserCardamount() {
		return userCardamount;
	}
	public void setUserCardamount(Integer userCardamount) {
		this.userCardamount = userCardamount;
	}
	public Integer getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(Integer userStatus) {
		this.userStatus = userStatus;
	}
	public String getUserCreateTime() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(userCreateTime.getTime());
		return dateString;
	}
	public void setUserCreateTime(Date userCreateTime) {
		this.userCreateTime = userCreateTime;
	}
	public Integer getUserSex() {
		return userSex;
	}
	public void setUserSex(Integer userSex) {
		this.userSex = userSex;
	}
	
	public String getUserBirthday() {
		return userBirthday;
	}

	public void setUserBirthday(String birthday) {
		this.userBirthday = birthday;
	}
	
	
	

}
