package com.ssm.pojo;

public class Game {
	private Integer id;
	private String gameName;
	private Integer gametypeId;
	private String gametypeName;
	private String gameImg;
	private String gameDeveloper;
	private String gameNumber;
	private String gameText;
	private String screenshotOne;
	private String screenshotTwo;
	private String screenshotThree;
	private String gameSynopsis;
	private String gameDetails;
	private String gameStatus;
	private Integer gamePrice;
	private Integer rmb;
	private String createTime;
	private String updateTime;
	
	public Game() {
	}



	public Game(Integer id, String gameName, Integer gametypeId,
			String gametypeName, String gameImg, String gameDeveloper,
			String gameNumber, String gameText, String screenshotOne,
			String screenshotTwo, String screenshotThree, String gameSynopsis,
			String gameDetails, String gameStatus, Integer gamePrice,
			Integer rmb, String createTime, String updateTime) {
		this.id = id;
		this.gameName = gameName;
		this.gametypeId = gametypeId;
		this.gametypeName = gametypeName;
		this.gameImg = gameImg;
		this.gameDeveloper = gameDeveloper;
		this.gameNumber = gameNumber;
		this.gameText = gameText;
		this.screenshotOne = screenshotOne;
		this.screenshotTwo = screenshotTwo;
		this.screenshotThree = screenshotThree;
		this.gameSynopsis = gameSynopsis;
		this.gameDetails = gameDetails;
		this.gameStatus = gameStatus;
		this.gamePrice = gamePrice;
		this.rmb = rmb;
		this.createTime = createTime;
		this.updateTime = updateTime;
	}



	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public String getGametypeName() {
		return gametypeName;
	}
	public void setGametypeName(String gametypeName) {
		this.gametypeName = gametypeName;
	}
	public String getGameImg() {
		return gameImg;
	}
	public void setGameImg(String gameImg) {
		this.gameImg = gameImg;
	}
	public String getGameStatus() {
		return gameStatus;
	}
	public void setGameStatus(String gameStatus) {
		this.gameStatus = gameStatus;
	}
	public Integer getGamePrice() {
		return gamePrice;
	}
	public void setGamePrice(Integer gamePrice) {
		this.gamePrice = gamePrice;
	}
	
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getRmb() {
		return rmb;
	}
	public void setRmb(Integer rmb) {
		this.rmb = rmb;
	}

	public String getGameDeveloper() {
		return gameDeveloper;
	}

	public void setGameDeveloper(String gameDeveloper) {
		this.gameDeveloper = gameDeveloper;
	}

	public String getGameNumber() {
		return gameNumber;
	}

	public void setGameNumber(String gameNumber) {
		this.gameNumber = gameNumber;
	}

	public String getScreenshotOne() {
		return screenshotOne;
	}

	public void setScreenshotOne(String screenshotOne) {
		this.screenshotOne = screenshotOne;
	}

	public String getScreenshotTwo() {
		return screenshotTwo;
	}

	public void setScreenshotTwo(String screenshotTwo) {
		this.screenshotTwo = screenshotTwo;
	}

	public String getScreenshotThree() {
		return screenshotThree;
	}

	public void setScreenshotThree(String screenshotThree) {
		this.screenshotThree = screenshotThree;
	}

	public String getGameSynopsis() {
		return gameSynopsis;
	}

	public void setGameSynopsis(String gameSynopsis) {
		this.gameSynopsis = gameSynopsis;
	}

	public String getGameDetails() {
		return gameDetails;
	}

	public void setGameDetails(String gameDetails) {
		this.gameDetails = gameDetails;
	}

	public Integer getGametypeId() {
		return gametypeId;
	}

	public void setGametypeId(Integer gametypeId) {
		this.gametypeId = gametypeId;
	}


	public String getGameText() {
		return gameText;
	}


	public void setGameText(String gameText) {
		this.gameText = gameText;
	}
	
	
}
