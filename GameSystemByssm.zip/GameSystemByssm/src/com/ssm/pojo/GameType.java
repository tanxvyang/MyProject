package com.ssm.pojo;

import java.util.Date;
import java.text.SimpleDateFormat;




public class GameType {
	private Integer id;
	private String typeName;
	private String typeStatus;
	private String typePicture;
	private Date createTime;
	private Date updateTime;
	
	
	@Override
	public String toString() {
		return "GameType [id=" + id + ", typeName=" + typeName
				+ ", typeStatus=" + typeStatus + ", typePicture=" + typePicture
				+ ", createTime=" + createTime + ", updateTime=" + updateTime
				+ "]";
	}
	public GameType() {
		super();
	}
	public GameType(Integer id, String typeName, String typeStatus,
			String typePicture, Date createTime, Date updateTime) {
		super();
		this.id = id;
		this.typeName = typeName;
		this.typeStatus = typeStatus;
		this.typePicture = typePicture;
		this.createTime = createTime;
		this.updateTime = updateTime;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getTypeStatus() {
		return typeStatus;
	}
	public void setTypeStatus(String typeStatus) {
		this.typeStatus = typeStatus;
	}
	public String getTypePicture() {
		return typePicture;
	}
	public void setTypePicture(String typePicture) {
		this.typePicture = typePicture;
	}
	public String getCreateTime() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String CreateTime = formatter.format(createTime.getTime());
		return CreateTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getUpdateTime() {
		if (updateTime!=null) {
			
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String UpdateTime = formatter.format(updateTime.getTime());
			return UpdateTime;
			}else {
				return "--.--";
			}
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
	

}
