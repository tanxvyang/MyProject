package com.ssm.pojo;


public class Recharge {
	private Integer userId;
	private String userName;
	private Integer cardId;
	private String cardNumber;
	private String cardPwd;
	private Integer price;
	private String effectiveEndTime;
	public Recharge() {
	}
	public Recharge(Integer userId, String userName, Integer cardId,
			String cardNumber, String cardPwd, Integer price,
			String effectiveEndTime) {
		this.userId = userId;
		this.userName = userName;
		this.cardId = cardId;
		this.cardNumber = cardNumber;
		this.cardPwd = cardPwd;
		this.price = price;
		this.effectiveEndTime = effectiveEndTime;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getCardId() {
		return cardId;
	}
	public void setCardId(Integer cardId) {
		this.cardId = cardId;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardPwd() {
		return cardPwd;
	}
	public void setCardPwd(String cardPwd) {
		this.cardPwd = cardPwd;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public String getEffectiveEndTime() {
		return effectiveEndTime;
	}
	public void setEffectiveEndTime(String effectiveEndTime) {
		this.effectiveEndTime = effectiveEndTime;
	}
	
}
