package com.ssm.pojo;

public class Prepaid {
	private String prepUserName;
	private String prepCardNum;
	private String prepCardPwd;
	private Integer prepAmount;
	private String prepEndTime;
	
	
	
	@Override
	public String toString() {
		return "Prepaid [prepUserName=" + prepUserName + ", prepCardNum="
				+ prepCardNum + ", prepCardPwd=" + prepCardPwd
				+ ", prepAmount=" + prepAmount + ", prepEndTime=" + prepEndTime
				+ "]";
	}
	public Prepaid() {
	}
	public Prepaid(String prepUserName, String prepCardNum, String prepCardPwd,
			Integer prepAmount, String prepEndTime) {
		this.prepUserName = prepUserName;
		this.prepCardNum = prepCardNum;
		this.prepCardPwd = prepCardPwd;
		this.prepAmount = prepAmount;
		this.prepEndTime = prepEndTime;
	}
	public String getPrepUserName() {
		return prepUserName;
	}
	public void setPrepUserName(String prepUserName) {
		this.prepUserName = prepUserName;
	}
	public String getPrepCardNum() {
		return prepCardNum;
	}
	public void setPrepCardNum(String prepCardNum) {
		this.prepCardNum = prepCardNum;
	}
	public String getPrepCardPwd() {
		return prepCardPwd;
	}
	public void setPrepCardPwd(String prepCardPwd) {
		this.prepCardPwd = prepCardPwd;
	}
	public Integer getPrepAmount() {
		return prepAmount;
	}
	public void setPrepAmount(Integer prepAmount) {
		this.prepAmount = prepAmount;
	}
	public String getPrepEndTime() {
		return prepEndTime;
	}
	public void setPrepEndTime(String prepEndTime) {
		this.prepEndTime = prepEndTime;
	}
	
	
	
}
