package com.ssm.pojo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Exchange {
	private Integer exchangeId;
	private Integer exchangeCityId;
	private Integer exchangeCharge;
	private Date exchangeCreateTime;
	private Date exchangeUpdateTime;
	private String exchangeStatus;
	public Exchange(Integer exchangeId, Integer exchangeCityId,
			Integer exchangeCharge, Date exchangeCreateTime,
			Date exchangeUpdateTime, String exchangeStatus) {
		super();
		this.exchangeId = exchangeId;
		this.exchangeCityId = exchangeCityId;
		this.exchangeCharge = exchangeCharge;
		this.exchangeCreateTime = exchangeCreateTime;
		this.exchangeUpdateTime = exchangeUpdateTime;
		this.exchangeStatus = exchangeStatus;
	}
	public Integer getExchangeId() {
		return exchangeId;
	}
	public void setExchangeId(Integer exchangeId) {
		this.exchangeId = exchangeId;
	}
	public Integer getExchangeCityId() {
		return exchangeCityId;
	}
	public void setExchangeCityId(Integer exchangeCityId) {
		this.exchangeCityId = exchangeCityId;
	}
	public Exchange() {
	}
	
	
	public Integer getExchangeCharge() {
		return exchangeCharge;
	}
	public void setExchangeCharge(Integer exchangeCharge) {
		this.exchangeCharge = exchangeCharge;
	}
	public String getExchangeCreateTime() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String CreateTime = formatter.format(exchangeCreateTime.getTime());
		return CreateTime;
	}
	public void setExchangeCreateTime(Date exchangeCreateTime) {
		this.exchangeCreateTime = exchangeCreateTime;
	}
	public String getExchangeUpdateTime() {
		if (exchangeUpdateTime!=null) {
			
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String UpdateTime = formatter.format(exchangeUpdateTime.getTime());
		return UpdateTime;
		}else {
			return "--.--";
		}
	}
	public void setExchangeUpdateTime(Date exchangeUpdateTime) {
		this.exchangeUpdateTime = exchangeUpdateTime;
	}
	public String getExchangeStatus() {
		return exchangeStatus;
	}
	public void setExchangeStatus(String exchangeStatus) {
		this.exchangeStatus = exchangeStatus;
	}
	
	
	
	
}
