package com.ssm.pojo;

public class Province {
private Integer id;
private String pro;




public Province() {
	super();
}
public Province(Integer id, String pro) {
	super();
	this.id = id;
	this.pro = pro;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getPro() {
	return pro;
}
public void setPro(String pro) {
	this.pro = pro;
}

}
