package com.ssm.pojo.vo;

import com.ssm.pojo.Card;

public class CardProviceVO {
   private Card card;
   private Integer Pid;
   
   public Integer getPid() {
	return Pid;
}
   private String cardCity;
   public CardProviceVO() {
	   super();
   }
public void setPid(Integer pid) {
	Pid = pid;
}
public CardProviceVO(Card card, Integer pid, String cardCity) {
	super();
	this.card = card;
	Pid = pid;
	this.cardCity = cardCity;
}
public Card getCard() {
	return card;
}
public void setCard(Card card) {
	this.card = card;
}
public String getCardCity() {
	return cardCity;
}
public void setCardCity(String cardCity) {
	this.cardCity = cardCity;
}
@Override
public String toString() {
	return "CardPrroviceVO [card=" + card + ", cardCity=" + cardCity + "]";
}
   
}
