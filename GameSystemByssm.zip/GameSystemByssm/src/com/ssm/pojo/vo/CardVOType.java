package com.ssm.pojo.vo;

import java.util.Date;

import com.ssm.pojo.Card;

public class CardVOType  extends Card{
	private String cardCity;

	public CardVOType(Integer id, String cardNumber, String cardPassword,
			Integer cardAmount, Integer cardCityId, String cardStartTime,
			String cardEndTime, String cardStatus, Date cardCreateTime,
			String cardCity) {
		super(id, cardNumber, cardPassword, cardAmount, cardCityId,
				cardStartTime, cardEndTime, cardStatus, cardCreateTime);
		this.cardCity = cardCity;
	}

	public CardVOType() {
		super();
	}

	public CardVOType(String cardCity) {
		this.cardCity = cardCity;
	}

	public String getCardCity() {
		return cardCity;
	}

	public void setCardCity(String cardCity) {
		this.cardCity = cardCity;
	}
}
