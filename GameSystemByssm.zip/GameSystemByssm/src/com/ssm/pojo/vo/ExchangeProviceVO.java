package com.ssm.pojo.vo;

import java.util.Date;

import com.ssm.pojo.Exchange;

public class ExchangeProviceVO {
	private Exchange exchange;
	private String exchangeCity;

	

	

	@Override
	public String toString() {
		return "ExchangeProviceVO [exchange=" + exchange + ", exchangeCity="
				+ exchangeCity + "]";
	}

	public ExchangeProviceVO() {
		super();
	}

	public ExchangeProviceVO(Exchange exchange, String exchangeCity) {
		super();
		this.exchange = exchange;
		this.exchangeCity = exchangeCity;
	}

	public Exchange getExchange() {
		
		return exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public String getExchangeCity() {
		return exchangeCity;
	}

	public void setExchangeCity(String exchangeCity) {
		this.exchangeCity = exchangeCity;
	}

	
	
	
}
