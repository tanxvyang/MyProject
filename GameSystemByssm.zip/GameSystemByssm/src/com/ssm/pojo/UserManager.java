package com.ssm.pojo;

import java.util.Date;

public class UserManager {
//	ID
//	--ROOT_NAME
//	--ROOT_PSW
//	--ROOT_PHONE
//	--CREATE_TIME
	private Integer id;
	private String rootName;
	private String rootPassword;
	private String rootPhone;
	private Date  createTime;
	
	
	
	
	public UserManager() {
		super();
	}
	public UserManager(Integer id, String rootName, String rootPassword,
			String rootPhone, Date createTime) {
		super();
		this.id = id;
		this.rootName = rootName;
		this.rootPassword = rootPassword;
		this.rootPhone = rootPhone;
		this.createTime = createTime;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getRootName() {
		return rootName;
	}
	public void setRootName(String rootName) {
		this.rootName = rootName;
	}
	public String getRootPassword() {
		return rootPassword;
	}
	public void setRootPassword(String rootPassword) {
		this.rootPassword = rootPassword;
	}
	public String getRootPhone() {
		return rootPhone;
	}
	public void setRootPhone(String rootPhone) {
		this.rootPhone = rootPhone;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	
	

}
