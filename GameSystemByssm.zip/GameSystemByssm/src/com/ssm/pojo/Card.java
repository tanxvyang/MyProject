package com.ssm.pojo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Card {
	private Integer id;
	private String cardNumber;
	private String cardPassword;
	private Integer cardAmount;
	private Integer cardCityId;
	private String cardStartTime;
	private String cardEndTime;
	private String cardStatus;
	private Date cardCreateTime;
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Card() {
		super();
	}
	public Card(Integer id, String cardNumber, String cardPassword,
			Integer cardAmount, Integer cardCityId, String cardStartTime,
			String cardEndTime, String cardStatus, Date cardCreateTime) {
		super();
		this.id = id;
		this.cardNumber = cardNumber;
		this.cardPassword = cardPassword;
		this.cardAmount = cardAmount;
		this.cardCityId=  cardCityId;
		this.cardStartTime = cardStartTime;
		this.cardEndTime = cardEndTime;
		this.cardStatus = cardStatus;
		this.cardCreateTime = cardCreateTime;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardPassword() {
		return cardPassword;
	}
	public void setCardPassword(String cardPassword) {
		this.cardPassword = cardPassword;
	}
	public Integer getCardAmount() {
		return cardAmount;
	}
	public void setCardAmount(Integer cardAmount) {
		this.cardAmount = cardAmount;
	}
	
	public String getCardStartTime() {
		return cardStartTime;
	}
	public void setCardStartTime(String cardStartTime) {
		this.cardStartTime = cardStartTime;
	}
	public String getCardEndTime() {
		return cardEndTime;
	}
	public void setCardEndTime(String cardEndTime) {
		this.cardEndTime = cardEndTime;
	}
	public String getCardStatus() {
		return cardStatus;
	}
	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}
	public String getCardCreateTime() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String CreateTime = formatter.format(cardCreateTime.getTime());
		return CreateTime;
	}
	public void setCardCreateTime(Date cardCreateTime) {
		this.cardCreateTime = cardCreateTime;
	}
	public Integer getCardCityId() {
		return cardCityId;
	}
	public void setCardCityId(Integer cardCityId) {
		this.cardCityId = cardCityId;
	}
	
	
	
}
