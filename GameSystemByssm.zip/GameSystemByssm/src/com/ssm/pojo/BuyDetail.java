package com.ssm.pojo;

public class BuyDetail {
	private Integer id;
	private Integer userId;
	private String userName;
	private String gameName;
	private String buyWay;
	private Integer gamePrice;
	private String firstTime;
	private String latestTime;
	private Integer downloadNum;
	
	public BuyDetail() {
	}

	public BuyDetail(Integer id, Integer userId, String userName,
			String gameName, String buyWay, Integer gamePrice,
			String firstTime, String latestTime, Integer downloadNum) {
		this.id = id;
		this.userId = userId;
		this.userName = userName;
		this.gameName = gameName;
		this.buyWay = buyWay;
		this.gamePrice = gamePrice;
		this.firstTime = firstTime;
		this.latestTime = latestTime;
		this.downloadNum = downloadNum;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public String getBuyWay() {
		return buyWay;
	}

	public void setBuyWay(String buyWay) {
		this.buyWay = buyWay;
	}

	public Integer getGamePrice() {
		return gamePrice;
	}

	public void setGamePrice(Integer gamePrice) {
		this.gamePrice = gamePrice;
	}

	public String getFirstTime() {
		return firstTime;
	}

	public void setFirstTime(String firstTime) {
		this.firstTime = firstTime;
	}

	public String getLatestTime() {
		return latestTime;
	}

	public void setLatestTime(String latestTime) {
		this.latestTime = latestTime;
	}

	public Integer getDownloadNum() {
		return downloadNum;
	}

	public void setDownloadNum(Integer downloadNum) {
		this.downloadNum = downloadNum;
	}
	
}
