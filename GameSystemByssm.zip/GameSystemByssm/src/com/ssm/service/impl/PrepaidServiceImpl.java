package com.ssm.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssm.dao.CardDao;
import com.ssm.dao.PrepaidDao;
import com.ssm.dao.UserDao;
import com.ssm.pojo.Card;
import com.ssm.pojo.Prepaid;
import com.ssm.pojo.User;
import com.ssm.service.PrepaidService;
@Service
public class PrepaidServiceImpl implements PrepaidService{
	
	@Autowired
	private PrepaidDao prepaidDao;
	
	@Autowired
	private CardDao cardDao;
	
	@Autowired
	private UserDao userDao;
	
	@Transactional
	public List<Prepaid> selectPrepaidByPrepUserName(String prepUserName) {
		List<Prepaid> prepaid =  prepaidDao.selectPrepaidByPrepUserName(prepUserName);
		return prepaid;
	}

	@Override
	public void recharge(Map<String, Object> map) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	//@Transactional
//	public void recharge(Map<String, Object> map) throws Exception{
//		String cardNumber = (String) map.get("cardNumber");
//		String cardPwd = (String) map.get("cardPwd");
//		String username = (String) map.get("username");
//		
//		Map<String, String> map1 = new HashMap<String, String>();
//		map1.put("cardNumber",cardNumber );
//		map1.put("cardPwd",cardPwd );
//		//Card card = cardDao.selectCard(map1);
////		
////		
////		if(card == null || card.equals("")){
////				throw new Exception("充值失败：卡号或密码输入错误");
////			}else{
//////				Integer amount = card.getCardAmount();
//////				String endTime = card.getCardEndTime();
////				
////				Prepaid prepaid = new Prepaid();
////				//prepaid.setPrepAmount(amount);
////				prepaid.setPrepCardNum(cardNumber);
////				prepaid.setPrepCardPwd(cardPwd);
////				//prepaid.setPrepEndTime(endTime);
////				prepaid.setPrepUserName(username);
////				
////				User user = userDao.selectUserByName(username);
////				
////				Map<String, String> map2 = new HashMap<String, String>();
////				map2.put("cardNumber",cardNumber );
////				map2.put("cardPwd",cardPwd );
////				
////			//	Integer userAmount = user.getUserCardamount()+card.getCardAmount();
////				Map<String, Object> map3 = new HashMap<String, Object>();
////				//map3.put("userAmount",userAmount );
////				map3.put("username",username );
////				
////				System.out.println("密保卡状态 = "+card.getCardStatus());
////				System.out.println("密保卡所在地 = "+card.getCardCity());
////				System.out.println("用户所在地 = "+user.getLocation());
////				
////				if(card.getCardStatus() == "正常" || card.getCardStatus().equals("正常")){
////					if(card.getCardCity() == user.getLocation() || card.getCardCity().equals(user.getLocation()) ){
////						prepaidDao.addPrepaid(prepaid);
////						cardDao.updateCard(map2);
////						userDao.updateUserAmount(map3);
////					}else{
////						throw new Exception("充值失败：充值地不符合");
//					}
////				}else{
////					throw new Exception("充值失败：该卡状态为:"+card.getCardStatus());
////				}
//			}
	
	}


