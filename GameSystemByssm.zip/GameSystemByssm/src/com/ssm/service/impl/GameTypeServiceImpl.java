package com.ssm.service.impl;

import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssm.dao.GameDao;
import com.ssm.dao.GameTypeDao;
import com.ssm.exception.GameTypeException;
import com.ssm.pojo.Game;
import com.ssm.pojo.GameType;
import com.ssm.service.GameTypeService;
import com.ssm.util.Constants;
import com.ssm.util.FileUtil;
import com.ssm.util.Pager;
@Service
public class GameTypeServiceImpl implements GameTypeService {
	@Autowired
	private GameTypeDao gameTypeDao;
	@Autowired
	private GameDao gameDao;
	@Transactional
	@Override
	public Pager<GameType> selectAllGameType(Integer pageNo,String typeName, String typeStatus)
			throws GameTypeException {
		Pager<GameType> pager = new Pager<GameType>();
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("typeName", typeName);
		map2.put("typeStatus", typeStatus);
		Integer totalCount = gameTypeDao.countGameType(map2);
		if(totalCount == null) {
			totalCount = 0;
		}
		pager.setTotalPage(totalCount, Constants.PAGE_SIZE_4);
		map2.put("pageNo",pageNo);
		map2.put("pageSize",4);
		List<GameType> gameType = gameTypeDao.selectAllGameType(map2);
		pager.setPageNo(Integer.parseInt(pageNo.toString()));
		pager.setList(gameType);
		return pager;
	}

	@Override
	@Transactional
	public void deleGameType(String typeName) throws GameTypeException {
		String[] arr = typeName.split(",");
		for (String typename : arr) {
			
			List<Game> games =  gameDao.selectGameByTypeName(typename);
		if( games.size() != 0){
			continue;
			//throw new GameTypeException("删除失败：该类型下有游戏");
		}else{
			if (!gameTypeDao.selectTypeByName(typename).getTypeStatus().equals("1")) {
				gameTypeDao.deleGameType(typename);
			}else{
				continue;
				//throw new GameTypeException("删除失败：该类型未下线");
			}
			//throw new GameTypeException("删除失败：该类型下有游戏");
		}
		}
	}

	
	@Override
	@Transactional
	public void updateType(Map<String, Object> map) throws GameTypeException {
		
		GameType findgameType = gameTypeDao.selectTypeByName(map.get("typeName").toString());
		if (findgameType != null && !findgameType.getId().equals(map.get("ID"))) {
			System.out.println(findgameType.getId());
			System.out.println(map.get("ID"));
			
			throw new GameTypeException("修改失败:该类型名已存在,请修改");
		}else{
			gameTypeDao.updateType(map);
		}
		
		
	}

	@Override
	@Transactional
	public void addGameType(GameType gameType, InputStream uploadFile,
			String imgPath, String suffix,String fileName) throws Exception {
		//判断游戏类型是否已经存在
		GameType findgameType = gameTypeDao.selectTypeByName(gameType.getTypeName());
		if(findgameType == null || findgameType.equals("")){
			
			if((fileName==null)||(fileName.equals(""))){
				gameType.setTypePicture("a.jpg");
				gameTypeDao.addGameType(gameType);
				return;
			}else{
				try {
					Date date = new Date();
					String up = String.valueOf( date.getTime());
				System.out.println(date.getTime());
					//文件上传
					FileUtil.uploadFile(uploadFile, imgPath+"/"+up+suffix);
					gameType.setTypePicture(up+suffix);
					gameTypeDao.addGameType(gameType);
				} catch (Exception e) {
					e.printStackTrace();
					throw e;
				}
			}
		}else{
			throw new GameTypeException("添加失败：类型名以存在");
		}
	}

	@Override
	@Transactional
	public List<GameType> selectType() throws GameTypeException {
		return gameTypeDao.selectType();
	}

	@Override
	@Transactional
	public GameType selectGameTypeByTypeName(String typeName)
			throws GameTypeException {
		return gameTypeDao.selectTypeByName(typeName);
	}

	@Override
	public GameType selectGameTypeById(Integer id) throws GameTypeException {
		// TODO Auto-generated method stub
		return gameTypeDao.selectTypeById(id);
	}

}
