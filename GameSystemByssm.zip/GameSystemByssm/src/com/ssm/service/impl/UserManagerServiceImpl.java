package com.ssm.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.dao.UserManagerDao;
import com.ssm.exception.LogineException;
import com.ssm.pojo.UserManager;
import com.ssm.service.UserManagerService;
@Service
public class UserManagerServiceImpl implements UserManagerService {
	@Autowired
	private UserManagerDao userManagerDao;
	@Override
	public UserManager login(String rootName, String rootPasseword) throws LogineException {
		//根据name password 查找用户
		UserManager userManager = userManagerDao.selectUserManagerByNP(rootName,rootPasseword);
		//判断用户是否存在,用短路的方式
		if ( userManagerDao.selectUserManagerByName(rootName) != null ) {
			//判断密码是否正确
			if ( !(userManager != null && userManager.getRootPassword().equals(rootPasseword))) {
				throw new LogineException("密码错误,请重新输入!");
			}
		}else{
			throw new LogineException("该用户不存在!请确认或注册!");
		}
		return userManager;
	}

}
