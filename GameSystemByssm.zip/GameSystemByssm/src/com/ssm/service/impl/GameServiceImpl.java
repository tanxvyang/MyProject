package com.ssm.service.impl;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssm.dao.BuyDetailDao;
import com.ssm.dao.GameDao;
import com.ssm.dao.GameTypeDao;
import com.ssm.exception.deleteGameException;
import com.ssm.pojo.Game;
import com.ssm.service.GameService;
import com.ssm.util.Constants;
import com.ssm.util.FileUtil;
import com.ssm.util.Pager;

@Service
public class GameServiceImpl implements GameService{
	@Autowired
	private GameDao gameDao;
	@Autowired
	private GameTypeDao gameTypeDao;
	@Autowired
	private BuyDetailDao buyDetailDao;
	
	@Transactional
	public Pager<Game> getGameByPager(Integer pageNo, String gameName,
			String gameTypeName) {
		Pager<Game> pager = new Pager<Game>();
		pager.setPageNo(pageNo);
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("gameName", gameName);
		map.put("gametypeName", gameTypeName);
		map.put("maxNum", (pageNo-1)*Constants.PAGE_SIZE_4);
		map.put("minNum", pageNo*Constants.PAGE_SIZE_4);

		List<Game> GameNum =gameDao.selectGameByPage(map);
		Integer totalCount =gameDao.countGameByCond(map);//获取满足条件的总页数
		pager.setTotalPage(totalCount, Constants.PAGE_SIZE_4);
		pager.setList(GameNum);
		return pager;
	}

	public void deleteGameById(Integer gameId) throws deleteGameException {
		if (gameDao.selectGameById(gameId).getGameStatus().equals("1")) {
			throw new deleteGameException("无法删除未下线游戏");
		}
		gameDao.deleteGameById(gameId);
		
	}

	//根据Id将信息发送到页面上
	public Game findGameById(Integer id) {
		return gameDao.selectGameById(id);
	}
	//添加一个游戏
	
	public void addGame(Game game, InputStream inputStream,
			InputStream inputStream1, InputStream inputStream2,
			InputStream inputStream3, String imgPath, String suffix
			,String suffix1,String suffix2,String suffix3,String suffix4,
			String fileName, String fileName1, String fileName2,
			String fileName3,String fileName4,InputStream is) throws Exception{
		String gameTypeName  =  game.getGametypeName();
		String filename = game.getGameName();
		Integer nameNum = gameDao.CountGameByName(filename);
		 if(nameNum!=0){
			throw new Exception("添加失败：游戏名字重复");
		}else if((fileName==null)||(fileName.equals(""))){
			throw new Exception("添加失败：请上传主图后再添加");
		}else if((fileName1==null)||(fileName1.equals(""))){
			throw new Exception("添加失败：请上传截图后再添加");
		}else if((fileName2==null)||(fileName2.equals(""))){
			throw new Exception("添加失败：请上传截图后再添加");
		}else if((fileName3==null)||(fileName3.equals(""))){
			throw new Exception("添加失败：请上传截图后再添加");
		}else if((fileName4==null)||(fileName4.equals(""))){
			throw new Exception("添加失败：请上传游戏文件后再添加");
		}else if(!(suffix4.endsWith(".txt"))){
			throw new Exception("添加失败：游戏文件是.txt格式");
		}
		 
		 
		// String filename = String.valueOf( new Date().getTime());
		 Integer nextid =gameDao.selectSEQ();
		File f = new File(imgPath+"/"+nextid+suffix4);
		try {
			f.createNewFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		OutputStream ostxt = null;
		try {
			
//			//文件上传
//			
//			String a = String.valueOf( new Date().getTime());
//			String b = String.valueOf( new Date().getTime());
//			String c = String.valueOf( new Date().getTime());
//			String d = String.valueOf( new Date().getTime());
//		
//			FileUtil.uploadFile(inputStream, imgPath+"/"+a+1+suffix);
//			game.setGameImg(a+1+suffix);
//			FileUtil.uploadFile(inputStream1, imgPath+"/"+b+2+suffix1);
//			game.setScreenshotOne(b+2+suffix1);
//			FileUtil.uploadFile(inputStream2, imgPath+"/"+c+3+suffix2);
//			game.setScreenshotTwo(c+3+suffix2);
//			FileUtil.uploadFile(inputStream3, imgPath+"/"+d+4+suffix3);
//			game.setScreenshotThree(d+4+suffix3);
			//文件上传
			FileUtil.uploadFile(inputStream, imgPath+"/"+nextid+suffix);
			game.setGameImg(nextid+suffix);
			Double b = nextid+0.1;
			FileUtil.uploadFile(inputStream1, imgPath+"/"+b+suffix1);
			game.setScreenshotOne(b+suffix1);
			Double c = nextid+0.2;
			FileUtil.uploadFile(inputStream2, imgPath+"/"+c+suffix2);
			game.setScreenshotTwo(c+suffix2);
			Double d = nextid+0.3;
			FileUtil.uploadFile(inputStream3, imgPath+"/"+d+suffix3);
			game.setScreenshotThree(d+suffix3);
			//如果文件上传成功,将用户头像置为用户上传的图片,同时对上面已经默认的1.jpg进行修改
			Integer gameTypeId =gameTypeDao.selectTypeByName(gameTypeName).getId();
			game.setGametypeId(gameTypeId);
//			System.out.println("fdsf2323400000000000=="+gameTypeId);
			
			//上传游戏文件
			ostxt = new FileOutputStream(f);
			byte[] bs = new byte[1024];
			int length = 0;
			while((length = is.read(bs)) != -1) {
				ostxt.write(bs, 0, length);
			}
			game.setGameText(nextid+suffix4);
			gameDao.insertGame(game);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(is != null) {
				try {
					is.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if(ostxt != null) {
				try {
					ostxt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	public Game getGameById(Integer id) {
		return gameDao.selectGameById(id);
	}
@Transactional
	public void updateGames(Game game,InputStream inputStream,
			InputStream inputStream2, InputStream inputStream3,
			InputStream inputStream4, String imgPath, String suffix,
			String suffix1, String suffix2, String suffix3, String fileName,
			String fileName1, String fileName2, String fileName3) throws Exception{
		//得到该游戏的id,name,从而判断除了这个名字外是否还有其他的，如果有则名字重复
		Integer id = game.getId();
		String oldGameName = gameDao.selectGameById(id).getGameName();
		String gameName = game.getGameName();
		Integer nameNum = gameDao.CountGameByName(gameName);
		//通过id得到名字和传进来的名字重复，则num-1
		if(gameDao.selectGameById(id).getGameName().equals(gameName)){
			nameNum= nameNum-1;
		}
		if(nameNum!=0){
			throw new Exception("修改失败：游戏名字重复");
		}
		//如果主图文件不为空，并且符合图片格式，则将文件上传，并且删除服务器中的对应的数据
		if(!fileName.equals("")){
			if((fileName.endsWith(".jpg"))||(fileName.endsWith(".png"))||(fileName.endsWith(".bmp"))){
				String imgName = gameDao.selectGameById(id).getGameImg();
				File file = new File(imgPath+"/"+imgName);
				file.delete();
				try {
					FileUtil.uploadFile(inputStream, imgPath+"/"+imgName);
				} catch (Exception e) {
					e.printStackTrace();
				}
			
			}else{
				throw new Exception("主图类型错误：必须上传图片(例如:1.jpg)");
				
			}
		
			
		}
		if(!fileName1.equals("")){
			if((fileName1.endsWith(".jpg"))||(fileName1.endsWith(".png"))||(fileName1.endsWith(".bmp"))){
					String imgOne = gameDao.selectGameById(id).getScreenshotOne();
//					System.out.println("第一张截图的名字是：=========="+imgOne);
					File file = new File(imgPath+"/"+imgOne);
					file.delete();
//					System.out.println("第一张截图的名字是：==========成功");
					try {
						FileUtil.uploadFile(inputStream2, imgPath+"/"+imgOne);
					} catch (Exception e) {
						e.printStackTrace();
					}
			}else{
				throw new Exception("第一张截图类型错误：必须上传图片(例如:1.jpg)");
			}
			
		}
		if(!fileName2.equals("")){
			if((fileName2.endsWith(".jpg"))||(fileName2.endsWith(".png"))||(fileName2.endsWith(".bmp"))){
					String imgTwo = gameDao.selectGameById(id).getScreenshotTwo();
					File file = new File(imgPath+"/"+imgTwo);
					file.delete();
					try {
						FileUtil.uploadFile(inputStream3, imgPath+"/"+imgTwo);
					} catch (Exception e) {
						e.printStackTrace();
					}
			}else{
				throw new Exception("第二张截图类型错误：必须上传图片(例如:1.jpg)");
				
			}
		}
		if(!fileName3.equals("")){
			if((fileName3.endsWith(".jpg"))||(fileName3.endsWith(".png"))||(fileName3.endsWith(".bmp"))){
					String imgThree = gameDao.selectGameById(id).getScreenshotThree();
					File file = new File(imgPath+"/"+imgThree);
					file.delete();
					try {
						FileUtil.uploadFile(inputStream4, imgPath+"/"+imgThree);
					} catch (Exception e) {
						e.printStackTrace();
					}
			}else{
				throw new Exception("第三张截图类型错误：必须上传图片(例如:1.jpg)");
			}
		}
		
		Integer gtid = gameTypeDao.selectTypeByName(game.getGametypeName()).getId();
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("gamePrice", game.getGamePrice());
		map.put("rmb", game.getRmb());
		map.put("gameName", game.getGameName());
		map.put("gameTypeId", gtid);
		map.put("gameTypeName", game.getGametypeName());
		map.put("gameStatus", game.getGameStatus());
		map.put("gameDeveloper", game.getGameDeveloper());
		map.put("gameNumber", game.getGameNumber());
		map.put("gameSynopsis", game.getGameSynopsis());
		map.put("gameDetails", game.getGameDetails());
		map.put("time", game.getUpdateTime());
		map.put("id", id);
		gameDao.updateGameById(map);	
		Map<String,Object> maps = new HashMap<String,Object>();
		String newGameName = game.getGameName();
		
		/**
		 * 修改用户记录表
		 */
		buyDetailDao.updateGameNameByGameName(newGameName,oldGameName);
		
		
		
	}

	public List<Game> getGamesByGameTypeName(String gameTypeName) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("gametypeName", gameTypeName);
		List<Game> game =gameDao.getGamesByGameTypeName(map);
		return game;
	}

	public Game getGameBygameName(String gameName) {
		return gameDao.getGameBygameName(gameName);
	}

	public String getGTS(String gameName) {
		String gametypeName = gameDao.getGameBygameName(gameName).getGametypeName();
		String gameTypeStatus = gameTypeDao.selectTypeByName(gametypeName).getTypeStatus();
		return gameTypeStatus;
	}

	public List<Game> getsomeGameImg() {
		List<Game> gameImg = gameDao.getsomeGameImg();
//		List<String> GI = new ArrayList<String>();
//		for (Game game : gameImg) {
//			GI.add(game.getGameImg());
//		}
		return gameImg;
	}

	public Game getGameByImg(String gameImg) {
		return gameDao.getGameByImg(gameImg);
	}
}
