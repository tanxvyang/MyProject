package com.ssm.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssm.dao.BuyDetailDao;
import com.ssm.dao.ExchangeDao;
import com.ssm.dao.GameDao;
import com.ssm.dao.ProvinceDao;
import com.ssm.dao.UserDao;
import com.ssm.pojo.BuyDetail;
import com.ssm.pojo.Exchange;
import com.ssm.pojo.Game;
import com.ssm.pojo.Province;
import com.ssm.pojo.User;
import com.ssm.service.BuyDetailService;
import com.ssm.util.Constants;
import com.ssm.util.Pager;
@Service
public class BuyDetailServiceImpl implements BuyDetailService{
	@Autowired
	private BuyDetailDao buyDetailDao;
	@Autowired
	private UserDao userDao;
	@Autowired
	private GameDao gameDao;
	@Autowired
	private ExchangeDao exchangeDao;
	@Autowired
	private  ProvinceDao provinceDao;
	@Transactional
	public Pager<BuyDetail> getBuyDetailByPager(Integer pageNo, String userName) {
		Pager<BuyDetail> pager = new Pager<BuyDetail>();
		pager.setPageNo(pageNo);
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("userName", userName);
		map.put("maxNum", (pageNo-1)*Constants.PAGE_SIZE_5);
		map.put("minNum", pageNo*Constants.PAGE_SIZE_5);
		List<BuyDetail> BuyDetailNum =buyDetailDao.selectBuyDetailByPage(map);
		Integer totalCount =buyDetailDao.countBuyDetailByCond(map);
		pager.setTotalPage(totalCount, Constants.PAGE_SIZE_5);
		pager.setList(BuyDetailNum);
		return pager;
	}
	public Integer addGame(String gameName,String userName,String buyWay) throws Exception {
		User user = userDao.selectUserByName(userName);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String firstTime = sdf.format(date);

		//第一步：查看该用户是否购买过这个游戏,如果没有==null,或者 num==3
//				则进行购买  ==null ，
//						第一步：扣费，先得到密保额和游币，rmb
//						第二步：查看什么样的支付方式，查看对应支付方式是否够用
//								如果是rmb支付，根据兑换比例对应的加 游币
//						第三步：进行对应的购买
//						第四步：添加将本次记录，购买次数为1
//				则进行购买  ==3 ，
//						第四步：修改次数为1；
		
//		否则得到下载次数
		Integer buyNum = buyDetailDao.selectBuyNumBygameName(gameName,userName);
//		通过名字得到用户的钱，游币，密保
//		通过游戏名字得到对应的游戏价格
		Game game = gameDao.getGameBygameName(gameName);
		Integer gameWayPrice = null;
		if (!game.getGameStatus().equals("1")) {
			throw new Exception("下载失败：该游戏已下线!");
		}
		if(buyNum==null||buyNum==3){
			
			if(buyWay.equals("话费支付")){
				Integer exchange = 1;
				if(user.getUserTariffe() < game.getRmb()){
					throw new Exception("下载失败：金额不够，请使用其他支付方式");
				}else{
					//将游币按照比例添加上
					String local =  userDao.selectUserByName(userName).getUserCity();
					Province province = provinceDao.findProByName(local);
					Exchange exchange1 = exchangeDao.selectExchangeByExchangeName(province.getId().toString());
					if(exchange1 == null){
						exchange = 1;
					}else {
						if(exchange1.getExchangeStatus().equals("1")){
							exchange = exchange1.getExchangeCharge();
						}else{
							exchange = 1;
						}
					}
					
					gameWayPrice = game.getRmb();
					//扣除话费
					Double UserTariffe = user.getUserTariffe()-game.getRmb();
					Integer userNewPrice = user.getUserCardamount() + game.getRmb()*exchange ;
					Map<String,Object> map = new HashMap<String,Object>();
					map.put("id", user.getUserId());
					map.put("UserTariffe", UserTariffe);
					map.put("UserCardamount", userNewPrice);
					userDao.updateRMBByuserId(map);
				}
			}
			if(buyWay.equals("游币支付")){
				Integer gameprice = game.getGamePrice();
				//用户游币和密保的总额度
				Integer all = user.getUserCurrency()+user.getUserCardamount();
				gameWayPrice = gameprice;
				//如果总的不够，则购买失败
				if(all<gameprice){
					throw new Exception("下载失败：金额不够，请使用其他支付方式");
				}
				//如果密保不够，但总的可以支付，则将密保归零，游币扣除对应的金额
				if((user.getUserCurrency()<gameprice)&&(all>=gameprice)){
					Integer other = gameprice-user.getUserCurrency();
					Integer newUserPrice = user.getUserCardamount()-other;
					Map<String,Object> map1 = new HashMap<String,Object>();
					map1.put("id", user.getUserId());
					map1.put("UserCurrency", 0);
					map1.put("UserCardamount", newUserPrice);
					userDao.updateSercurityByuserId(map1);
				}
				//如果密保够用，扣密保
				if(user.getUserCurrency()>=gameprice){
					Integer newUserCurrency = user.getUserCurrency()-gameprice;
					Map<String,Object> map2 = new HashMap<String,Object>();
					map2.put("id", user.getUserId());
					map2.put("UserCurrency", newUserCurrency);
					userDao.updateSercuritysByuserId(map2);
				}
			}
			//添加购买信息将次数改为1
			if(buyNum==null){
				Map<String,Object> map3 = new HashMap<String,Object>();
				map3.put("userId", user.getUserId());
				map3.put("userName", user.getUserName());
				map3.put("gameName", gameName);
				map3.put("buyWay", buyWay);
				map3.put("gamePrice",gameWayPrice);
				map3.put("firstTime", firstTime);
				map3.put("latestTime", firstTime);
				map3.put("downloadNum", 1);
				buyDetailDao.addbuyDetail(map3);
			}else if(buyNum==3){
				Map<String,Object> map4 = new HashMap<String,Object>();
				map4.put("userId", user.getUserId());
				map4.put("downloadNum", 1);
				map4.put("latestTime", firstTime);
				map4.put("gameName", gameName);
				buyDetailDao.updatedownloadNum(map4);
			}
		}else if(buyNum==1){
			Map<String,Object> map5 = new HashMap<String,Object>();
			map5.put("userId", user.getUserId());
			map5.put("downloadNum", 2);
			map5.put("gameName", gameName);
			buyDetailDao.updatedownloadNums(map5);
		}else if(buyNum==2){
			Map<String,Object> map6 = new HashMap<String,Object>();
			map6.put("userId", user.getUserId());
			map6.put("downloadNum", 3);
			map6.put("gameName", gameName);
			buyDetailDao.updatedownloadNums1(map6);
		}
		//如果buyNum=4,被封禁；
		if(user.getUserStatus() != 1){
			buyNum=4;
		}
		return buyNum;
	}
	public Integer getGameMessage(String gameName, String userName) {
		Integer num ;
		num = buyDetailDao.selectBuyNumBygameName(gameName, userName);
		if(gameDao.getGameBygameName(gameName).getGameStatus().equals("2")){
			num=4;
		}
		return num;
	}
	public void overtime(String gameName, String userName) throws Exception {
		User user = userDao.selectUserByName(userName);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String firstTime = sdf.format(date);
		//得到最新购买的时间，如果超过了现在的时间24小时，则将num=3;
		String latestTime = buyDetailDao.selectLatestTimeBygameName(gameName, userName);
        Date start = sdf.parse(firstTime); 
        Date end = sdf.parse(latestTime);
        long cha = start.getTime() - end.getTime(); 
        double result = cha * 1.0 / (1000 * 60 * 60);
        if(result > 24){ 
        	Map<String,Object> map5 = new HashMap<String,Object>();
			map5.put("userId", user.getUserId());
			map5.put("downloadNum", 3);
			map5.put("gameName", gameName);
			buyDetailDao.overtimeupdate(map5);
        }		
	}
	
}
