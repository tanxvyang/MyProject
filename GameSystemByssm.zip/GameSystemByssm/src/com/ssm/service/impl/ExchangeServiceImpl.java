package com.ssm.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssm.dao.ExchangeDao;
import com.ssm.exception.DeleExchangeException;
import com.ssm.pojo.Exchange;
import com.ssm.pojo.vo.ExchangeProviceVO;
import com.ssm.service.ExchangeService;
import com.ssm.util.Constants;
import com.ssm.util.Pager;

@Service
public class ExchangeServiceImpl implements ExchangeService{
	
	@Autowired
	private ExchangeDao exchangeDao;
	
	@Transactional
	public Pager<ExchangeProviceVO> selectAllExchange(Map<String, Object> map)
			throws Exception {
		Pager<ExchangeProviceVO> pager = new Pager<ExchangeProviceVO>();
		pager.setPageNo(Integer.parseInt(map.get("pageNo").toString()));
		Integer totalCount = exchangeDao.countExchange(map);
		if(totalCount == null) {
			totalCount = 0;
		}
		pager.setTotalPage(totalCount, Constants.PAGE_SIZE_4);
		map.put("pageSize",4);
		List<ExchangeProviceVO> exchanges = exchangeDao.selectAllExchange(map);
		pager.setList(exchanges);
		return pager;
	}
	
	@Transactional
	public void deleExchange(String exchangeid) throws DeleExchangeException{
		String[] arr = exchangeid.split(",");  //字符串转数组
		for (String string : arr) {
			if (!exchangeDao.selectGameByExchangeName(Integer.valueOf(string)).getExchange().getExchangeStatus().equals("1")) {
				exchangeDao.deleExchange(Integer.valueOf(string));
			}else{
				continue;
			}
		}
	}

	public ExchangeProviceVO selectGameByExchangeName(Integer exchangeid)
			throws Exception {
		return exchangeDao.selectGameByExchangeName(exchangeid);
	}
	
	@Transactional
	public void updateExchange(Integer exchangeId,Integer exchangeCharge,String exchangeStatus) throws Exception {
		System.out.println(exchangeStatus);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("exchangeId",exchangeId);
		map.put("exchangeCharge",exchangeCharge);
		map.put("exchangeStatus",exchangeStatus);
		exchangeDao.updateExchange(map);
	}

	public Exchange selectExchangeByExchangeName(String exchangeCity)
			throws Exception {
		return exchangeDao.selectExchangeByExchangeName(exchangeCity);
	}
	
	@Transactional
	public void addExchange(Exchange exchange) throws Exception {
		
		
		exchangeDao.addExchange(exchange);
		
		
	}

}
