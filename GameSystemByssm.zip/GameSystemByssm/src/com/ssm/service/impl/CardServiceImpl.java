package com.ssm.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssm.dao.CardDao;
import com.ssm.exception.AddCardException;
import com.ssm.pojo.Card;
import com.ssm.pojo.vo.CardVOType;
import com.ssm.service.CardService;
import com.ssm.util.Constants;
import com.ssm.util.Pager;

@Service
public class CardServiceImpl implements CardService{
	
	@Autowired
	private CardDao cardDao;
	
	@Transactional
	public Pager<CardVOType> selectAllCard(Map<String, Object> map) throws Exception {
		Pager<CardVOType> pager = new Pager<CardVOType>();
		pager.setPageNo(Integer.parseInt(map.get("pageNo").toString()));
		Integer totalCount = cardDao.countCard(map);
		System.out.println("totalCount="+totalCount);
		if(totalCount == null) {
			totalCount = 0;
		}
		pager.setTotalPage(totalCount, Constants.PAGE_SIZE_4);
		map.put("pageSize",4);
		List<CardVOType> cards = cardDao.TestselectAllCard(map);
		System.out.println("ServiceImpl-cards.size()="+cards.size());
		pager.setList(cards);
		return pager;
	}
//	@Transactional
//	public Pager<CardProviceVO> selectAllCard(Map<String, Object> map) throws Exception {
//		Pager<CardProviceVO> pager = new Pager<CardProviceVO>();
//		pager.setPageNo(Integer.parseInt(map.get("pageNo").toString()));
//		Integer totalCount = cardDao.countCard(map);
//		System.out.println("totalCount="+totalCount);
//		if(totalCount == null) {
//			totalCount = 0;
//		}
//		pager.setTotalPage(totalCount, Constants.PAGE_SIZE_4);
//		map.put("pageSize",4);
//		List<CardProviceVO> cards = cardDao.selectAllCard(map);
//		System.out.println("ServiceImpl-cards.size()="+cards.size());
//		pager.setList(cards);
//		return pager;
//	}
	
	@Transactional
	public void addCard(Integer num,String city,Integer cardAmount,String cardStartTime,String cardEndTime) throws AddCardException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String a = sdf.format(date);
			Card card = new Card();
			if((a.compareTo(cardStartTime)>=0)&&(a.compareTo(cardEndTime)<=0)){
				card.setCardStatus("正常");
			}else if(a.compareTo(cardEndTime)>0){
				card.setCardStatus("过期");
			}else
			if(a.compareTo(cardStartTime)<0){
				card.setCardStatus("未生效");
			}
			if (cardAmount <= 0) {
				throw new  AddCardException("密保卡金额必须大于零");
			}
			for(int i=0;i<num;i++){
				String cardNumber = RandomStringUtils.randomAlphanumeric(12).toLowerCase().toUpperCase();
				//随机生成数字加字母的字符串
				String cardPassword = RandomStringUtils.randomAlphanumeric(6).toLowerCase().toUpperCase();
				card.setCardNumber(cardNumber);
				card.setCardPassword(cardPassword);
				card.setCardAmount(cardAmount);
				card.setCardCityId(Integer.valueOf(city));
				card.setCardStartTime(cardStartTime);
				card.setCardEndTime(cardEndTime);
			    cardDao.addCard( card);
			
		}
	}
	@Override
	public void updateCardTime() throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		List<Card> list = cardDao.selectCardForUpdateTime();
		for (Card card : list) {
			if(!card.getCardStatus().equals("已使用")){
				String cardStatus = null;
				//获取当前所循环的卡号
				String cardNumber = card.getCardNumber();
				//获取数据库中开始和结束时间
				String start =  card.getCardStartTime();
				String end =  card.getCardEndTime();
				//数据库中开始和结束时间的毫秒数
				Date starts = sdf.parse(start);
				Date ends = sdf.parse(end);
				//当前时间的毫秒数
				Date date = new Date();
				if(starts.getTime() > date.getTime()){
					cardStatus = "未生效";
				}
				if(starts.getTime() < date.getTime() && ends.getTime() > date.getTime()){
					cardStatus = "正常";
				}
				if(ends.getTime() < date.getTime()){
					cardStatus = "过期";
				}
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("cardNumber", cardNumber);
				map.put("cardStatus", cardStatus);
				cardDao.updateCardTime(map);
			}
		
		}
		
	}

}
