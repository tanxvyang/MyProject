package com.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.dao.ProvinceDao;
import com.ssm.pojo.Province;
import com.ssm.service.ProvinceService;
@Service
public class ProvinceServiceImpl implements ProvinceService{
@Autowired
private ProvinceDao provinceDao;

public Province findProByName(String pro) {
	return provinceDao.findProByName(pro);
}

public List<Province> getAllProvince() {
	return provinceDao.getAllProvince();
}


}
