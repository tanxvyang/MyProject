package com.ssm.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.dao.CardDao;
import com.ssm.dao.RechargeDao;
import com.ssm.dao.UserDao;
import com.ssm.exception.LogineException;
import com.ssm.exception.RegistException;
import com.ssm.pojo.User;
import com.ssm.pojo.vo.CardProviceVO;
import com.ssm.service.UserService;
import com.ssm.util.Constants;
import com.ssm.util.Pager;
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao userDao;
	@Autowired
	private CardDao cardDao;
	@Autowired
	private RechargeDao rechargeDao;
	@Override
	public Pager<User> getUserByPage(Integer pageNo,String userName, String userPhone) {
		Pager<User> pager = new Pager<User>();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("userName",userName );
		map.put("userPhone",userPhone );
		
		 Integer totalCount = userDao.countUser(map); 
		 
		 if(totalCount == null) {
				totalCount = 0;
			}
		 map.put("pageNo",pageNo );
		 map.put("pageSize",Constants.PAGE_SIZE_4 );
		
		List<User> users = userDao.selectUserByCondAndPage(map);

		pager.setPageNo(pageNo);
		pager.setTotalPage(totalCount,Constants.PAGE_SIZE_4);
		pager.setList(users);
		return pager;
		
	}
	@Override
	public User login(String username, String password) throws LogineException {
		//根据name password 查找用户
				User user = userDao.selectUserByNP(username,password);
				//判断用户是否存在,用短路的方式
				if ( userDao.selectUserByName(username) != null ) {
					//判断密码是否正确
					if ( !(user != null && user.getUserPwd().equals(password))) {
						throw new LogineException("密码错误,请重新输入!");
					}else if( user.getUserStatus() != 1){
						throw new LogineException("该用户已被封禁!");
					}
					
				}else{
					throw new LogineException("该用户不存在!请确认或注册!");
				}
				return user;
			}
	
	@Override
	public void regist(User user) throws RegistException {
		try {
			User FindUser =  userDao.selectUserByName(user.getUserName());
			if (FindUser!= null) {
				throw new RegistException("用户名'"+user.getUserName()+"'已被使用,请重新输入");
			} else {
				if (userDao.selectUserPhone(user.getUserPhone())!=null) {
					throw new RegistException("手机号'"+user.getUserPhone()+"'已被使用,请重新输入");
				}else{
					userDao.addUser(user);
				}
			}
		} catch (RegistException e) {
			throw new RegistException("添加失败！"+e.getMessage());
		}
		
		
	}
	@Override
	public void modifyUserStatus(Integer status, String chooseUser) {
		Map<String, Object> map = new HashMap<String, Object>();
		String[] arr = chooseUser.split(",");  //字符串转数组
		map.put("status",status );    //状态
		//方法一,遍历,修改多次
		for (String string : arr) {
			map.put("chooseUser",Integer.valueOf(string));  //被修改的用户
			
			if (!userDao.selectUserById(map).getUserStatus().equals(status)) {
				userDao.updataStatus(map);
			}else{
				continue;
			}
		}
		
		//方法二 ,直接使用    in(1,2,3,4)
		
	}
	@Override
	public User getUserMessage(String username) {
		return userDao.selectUserByName(username);
	}
	
	@Override
	public void addMoney(String cardNumber, String cardPwd, String userName) throws Exception {
		User user = userDao.selectUserByName(userName);
		 if ( user.getUserStatus()!=1) {
			throw new Exception("用户状态异常,无法充值");
		}else{
		
			Map<String, Object> map = new HashMap<String, Object>();
		    map.put("cardNumber",cardNumber);
		    map.put("cardPwd",cardPwd);
		    CardProviceVO card = cardDao.selectCard(map);
		if (card!=null) {
			if (!card.getCardCity().equals(user.getUserCity())) {
				throw new Exception("该密保卡不属于您所在的城市,请核对!");
			}
			String status=card.getCard().getCardStatus();
			if(status.equals("正常")){
				cardDao.updateCard(map);
				map.put("userId", user.getUserId());
				map.put("userName", userName);
				map.put("cardId", card.getCard().getId());
				map.put("price", card.getCard().getCardAmount());
				map.put("effectiveEndTime", card.getCard().getCardEndTime());
				//先增记录
				rechargeDao.insertRecharge(map);
				Map<String,Object> updateSercurity = new HashMap<String,Object>();
				updateSercurity.put("id",user.getUserId());
				updateSercurity.put("UserCardamount",user.getUserCurrency()+card.getCard().getCardAmount() );
				//再改状态 充值到游币中
				userDao.RechargeByuserId(updateSercurity);
			}
			if(status.equals("过期")){
				throw new Exception("充值失败，该密保卡已经过期");
			}
			if(status.equals("未生效")){
				throw new Exception("充值失败，请等到密保卡生效后充值");
			}
			if(status.equals("已使用")){
				throw new Exception("充值失败，该密保卡已经使用");
			}
		}else{
			throw new Exception("密保卡号或密码不正确,请您核对后输入!");
		}
		}
	}
	@Override
	public void updatePwd(String pwd, String userName) {
		userDao.updatePwd(pwd,userName);
		
	}

}
