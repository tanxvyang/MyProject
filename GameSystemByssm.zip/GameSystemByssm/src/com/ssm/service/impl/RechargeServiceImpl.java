package com.ssm.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssm.dao.RechargeDao;
import com.ssm.pojo.GameType;
import com.ssm.pojo.Recharge;
import com.ssm.service.RechargeService;
import com.ssm.util.Constants;
import com.ssm.util.Pager;
@Service

public class RechargeServiceImpl implements RechargeService{
	@Autowired
	private RechargeDao rechargeDao;
	@Transactional
	public Pager<Recharge> getRechargeByPager(Integer pageNo,String userName) {
		Pager<Recharge> pager = new Pager<Recharge>();
		pager.setPageNo(pageNo);
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("userName", userName);
		map.put("maxNum", (pageNo-1)*Constants.PAGE_SIZE_4);
		map.put("minNum", pageNo*Constants.PAGE_SIZE_4);
		List<Recharge> rechargeNum =rechargeDao.selectRechargeByPage(map);
		Integer totalCount =rechargeDao.countRechargeDaoByCond(map);//获取满足条件的总页数
		pager.setTotalPage(totalCount, Constants.PAGE_SIZE_4);
		pager.setList(rechargeNum);
		return pager;
	}

}
