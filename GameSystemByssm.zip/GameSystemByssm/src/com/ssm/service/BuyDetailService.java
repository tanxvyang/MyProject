package com.ssm.service;

import com.ssm.pojo.BuyDetail;
import com.ssm.util.Pager;

public interface BuyDetailService {
	public Integer addGame(String gameName,String userName,String buyWay) throws Exception;

	public Pager<BuyDetail> getBuyDetailByPager(Integer pageNo, String userName);

	public Integer getGameMessage(String gameName, String userName);
	//超过时间修改
	public void overtime(String gameName, String userName) throws Exception;

}
