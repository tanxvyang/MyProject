package com.ssm.service;

import java.util.List;

import com.ssm.pojo.Province;

public interface ProvinceService {
	public Province findProByName(String pro);

	public List<Province> getAllProvince();
	
}
