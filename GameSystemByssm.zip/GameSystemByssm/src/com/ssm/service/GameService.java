package com.ssm.service;

import java.io.InputStream;
import java.util.List;

import com.ssm.exception.deleteGameException;
import com.ssm.pojo.Game;
import com.ssm.pojo.GameType;
import com.ssm.util.Pager;

public interface GameService {
	//分页
	public Pager<Game> getGameByPager(Integer pageNo, String gameName,
			String gameTypeName);

	public void deleteGameById(Integer gameId) throws deleteGameException;

	public Game findGameById(Integer id);


	public void addGame(Game game, InputStream inputStream,
			InputStream inputStream2, InputStream inputStream3,
			InputStream inputStream4, String imgPath, String suffix,
			String suffix1, String suffix2, String suffix3,String suffix4, String fileName,
			String fileName1, String fileName2, String fileName3,String fileName4,InputStream is)throws Exception;
	//详情页
	public Game getGameById(Integer id);

	public void updateGames(Game game, InputStream inputStream,
			InputStream inputStream2, InputStream inputStream3,
			InputStream inputStream4, String imgPath, String suffix,
			String suffix1, String suffix2, String suffix3, String fileName,
			String fileName1, String fileName2, String fileName3)throws Exception;
	//用户主页面导航栏得到对应的游戏
	public List<Game> getGamesByGameTypeName(String gameTypeName);
	//用户购买页详情
	public Game getGameBygameName(String gameName);
	//得到游戏类型的状态
	public String getGTS(String gameName);
//得到四张滚动页面图片
	public List<Game> getsomeGameImg();
//得到四张滚动页面图片,进入详情页面
	public Game getGameByImg(String gameImg);

}
