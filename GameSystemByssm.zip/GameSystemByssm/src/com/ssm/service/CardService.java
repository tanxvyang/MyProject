package com.ssm.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssm.exception.AddCardException;
import com.ssm.pojo.Card;
import com.ssm.pojo.vo.CardProviceVO;
import com.ssm.pojo.vo.CardVOType;
import com.ssm.util.Pager;

public interface CardService {
	public Pager<CardVOType> selectAllCard(Map<String, Object> map)throws Exception;

	public void addCard(Integer num,String city,Integer cardAmount,String cardStartTime,String cardEndTime)throws AddCardException;

	public void updateCardTime()throws Exception;

}
