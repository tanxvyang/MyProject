package com.ssm.service;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.ssm.exception.GameTypeException;
import com.ssm.pojo.GameType;
import com.ssm.util.Pager;

public interface GameTypeService {
	public Pager<GameType> selectAllGameType(Integer pageNo,String typeName, String typeStatus) throws GameTypeException ;
    public void deleGameType(String typeName)throws GameTypeException;
	public void updateType(Map<String, Object> map)throws GameTypeException;
	public void addGameType(GameType gameType, InputStream uploadFile,
			String imgPath, String suffix,String fileName)throws GameTypeException, Exception;
	public List<GameType> selectType()throws GameTypeException;
	public GameType selectGameTypeByTypeName(String typeName)throws GameTypeException;
	public GameType selectGameTypeById(Integer id)throws GameTypeException;
}
