package com.ssm.service;

import java.util.Map;

import com.ssm.exception.DeleExchangeException;
import com.ssm.pojo.Exchange;
import com.ssm.pojo.vo.ExchangeProviceVO;
import com.ssm.util.Pager;

public interface ExchangeService {
	public Pager<ExchangeProviceVO> selectAllExchange(Map<String, Object> map)throws Exception;

	public void deleExchange(String exchangeid)throws DeleExchangeException;

	public ExchangeProviceVO selectGameByExchangeName(Integer exchangeid)throws Exception;

	public void updateExchange(Integer exchangeId,Integer exchangeCharge,String exchangeStatus)throws Exception;

	public Exchange selectExchangeByExchangeName(String exchangeCity)throws Exception;

	public void addExchange(Exchange exchange)throws Exception;
}
