package com.ssm.service;

import com.ssm.pojo.Recharge;
import com.ssm.util.Pager;

public interface RechargeService {

	public Pager<Recharge> getRechargeByPager(Integer pageNo, String userName);
}
