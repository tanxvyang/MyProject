package com.ssm.service;

import com.ssm.exception.LogineException;
import com.ssm.pojo.UserManager;

public interface UserManagerService {

	public UserManager login(String rootName, String rootPasseword) throws LogineException;

}
