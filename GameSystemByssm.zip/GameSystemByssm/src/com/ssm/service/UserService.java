package com.ssm.service;

import com.ssm.exception.LogineException;
import com.ssm.exception.RegistException;
import com.ssm.pojo.User;
import com.ssm.util.Pager;

public interface UserService {

	public Pager<User> getUserByPage(Integer pageNo, String userName, String userPhone);

	public User login(String username, String password)throws LogineException;

	public void regist(User user) throws RegistException;

	public void modifyUserStatus(Integer status, String chooseUser) throws Exception;

	public User getUserMessage(String username);

	public void addMoney(String cardNumber, String cardPwd, String userName) throws Exception;

	public void updatePwd(String pwd, String userName);

}
