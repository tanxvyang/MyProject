package com.ssm.service;

import java.util.List;
import java.util.Map;

import com.ssm.pojo.Prepaid;

public interface PrepaidService {
	public List<Prepaid> selectPrepaidByPrepUserName(String prepUserName);
	
	public void recharge(Map<String, Object> map)throws Exception;
}
