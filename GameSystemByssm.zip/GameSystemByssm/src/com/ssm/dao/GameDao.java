package com.ssm.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.ssm.pojo.Game;

public interface GameDao {
	public List<Game> selectGameByPage(Map<String, Object> map);
	public Integer countGameByCond(Map<String, Object> map);
	public void deleteGameById(Integer gameId);
	public List<Game> selectGameByTypeName(@Param("typeName")String typeName);
	//后台游戏详情页
	public Game selectGameById(Integer id);
	public Integer CountGameById(Integer id);
	public Integer CountGameByName(String name);
	public void insertGame(Game game);
	public void updateGameById(Map<String, Object> map);
	//用户主页面导航栏得到对应的游戏
	public List<Game> getGamesByGameTypeName(Map<String, Object> map);
	//用户购买详情页
	public Game getGameBygameName(String gameName);
	//修改游戏类型名字时，类型为下线，游戏中的类型名和游戏状态都得修改
	public void updateGSAndGTNById(Map<String, Object> map);
	//修改游戏类型名字时，类型为商用，仅仅修改类型名字
	public void updateGameTypeName(Map<String, Object> map2);
	public Integer CountGameByGameTypeName(String gameTypeName);
	//得到四张滚动图片
	public List<Game> getsomeGameImg();
	public Game getGameByImg(String gameImg);
	public Integer CountGameByGameTypeNameId(Integer a);
	public Integer selectSEQ();
}
