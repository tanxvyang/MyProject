package com.ssm.dao;

import java.util.List;
import java.util.Map;

import com.ssm.pojo.User;
import com.ssm.util.Pager;

public interface UserDao {


 public List<User> selectUserByCondAndPage(Map<String, Object> map);
 public Integer countUser(Map<String, Object> map);
public User selectUserByName(String userName);

public User selectUserByNP(String userName , String userPwd);
public void addUser(User user);
public void updataStatus(Map<String, Object> map);
public User selectUserById(Map<String, Object> map);
public User selectUserPhone(String userPhone);
public void updateRMBByuserId(Map<String, Object> map);
public void updateSercurityByuserId(Map<String, Object> map1);
public void updateSercuritysByuserId(Map<String, Object> map2);
public void RechargeByuserId(Map<String, Object> updateSercurity);
public void updatePwd(String pwd, String userName);


}
