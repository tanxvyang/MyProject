package com.ssm.dao;

import java.util.List;
import java.util.Map;

import com.ssm.pojo.Recharge;

public interface RechargeDao {
	public void insertRecharge(Map<String, Object> rechargeMap);

	public Integer countRechargeDaoByCond(Map<String, Object> map);

	public List<Recharge> selectRechargeByPage(Map<String, Object> map);
	
}
