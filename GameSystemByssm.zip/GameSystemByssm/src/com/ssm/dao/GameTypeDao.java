package com.ssm.dao;

import java.util.List;
import java.util.Map;

import com.ssm.pojo.GameType;

public interface GameTypeDao {
	public Integer countGameType(Map<String, Object> map);

	public List<GameType> selectAllGameType(Map<String, Object> map);
	
	public void deleGameType(String typeName);
	
	public void updateType(Map<String, Object> map);
	
	public void addGameType(GameType gameType);
	
	public GameType selectTypeByName(String typeName);
	
	public List<GameType> selectType();

	public GameType selectTypeById(Integer id);
}
