package com.ssm.dao.impl;

import java.util.List;


import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Repository;

import com.ssm.dao.GameDao;
import com.ssm.pojo.Game;
import com.ssm.pojo.GameType;
@Repository
public class GameDaoImpl implements GameDao{
	private GameDao gameDao;
	
	public List<Game> selectGameByPage(Map<String, Object> map) {
		return gameDao.selectGameByPage(map);
	}

	public Integer countGameByCond(Map<String, Object> map) {
		return gameDao.countGameByCond(map);
	}
	//删除所选的游戏
	public void deleteGameById(Integer gameId) {
		gameDao.deleteGameById(gameId);
	}
	public Game selectGameById(Integer id) {
		return gameDao.selectGameById(id);
	}
	public Integer CountGameById(Integer id) {
		return gameDao.CountGameById(id);
	}
	public Integer CountGameByName(String name) {
		return gameDao.CountGameByName(name);
	}
	public void insertGame(Game game) {
		gameDao.insertGame(game);
	}
	
	public void updateGameById(Map<String, Object> map) {
		gameDao.updateGameById(map);
	}
	public List<Game> getGamesByGameTypeName(Map<String, Object> map) {
		return gameDao.getGamesByGameTypeName(map);
	}
	public Game getGameBygameName(String gameName) {
		return gameDao.getGameBygameName(gameName);
	}
	public void updateGSAndGTNById(Map<String, Object> map) {
		gameDao.updateGSAndGTNById(map);
	}
	public void updateGameTypeName(Map<String, Object> map2) {
		gameDao.updateGameTypeName(map2);
	}
	public Integer CountGameByGameTypeName(String gameTypeName) {
		return gameDao.CountGameByGameTypeName(gameTypeName);
	}
	public List<Game> getsomeGameImg() {
		return gameDao.getsomeGameImg();
	}
	public Game getGameByImg(String gameImg) {
		return gameDao.getGameByImg(gameImg);
	}
	public Integer CountGameByGameTypeNameId(Integer a) {
		return gameDao.CountGameByGameTypeNameId(a);
	}

	@Override
	public List<Game> selectGameByTypeName(String typeName) {
		List<Game> games = gameDao.selectGameByTypeName(typeName);
		return games;
	}
	
	
	
	public void setFactory(SqlSessionFactory factory) {
		this.gameDao = factory.openSession().getMapper(GameDao.class);
	}

	@Override
	public Integer selectSEQ() {
		
		return gameDao.selectSEQ();
	}

















	












}
