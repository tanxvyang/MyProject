package com.ssm.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssm.dao.CardDao;
import com.ssm.pojo.Card;
import com.ssm.pojo.vo.CardProviceVO;
import com.ssm.pojo.vo.CardVOType;



@Repository
public class CardDaoImpl implements CardDao{
	
	private CardDao cardDao;
	@Override
	public Integer countCard(Map<String, Object> map) {
		Integer count = cardDao.countCard(map);
		return count;
	}
	@Override
	public List<CardProviceVO> selectAllCard(Map<String, Object> map) {
		System.out.println("============进入CardDaoImpl=========================");
		List<CardProviceVO> cards = cardDao.selectAllCard(map);
		System.out.println("daoImplcards================="+cards.size());
		return cards;
	}
	@Override
	public void addCard(Card card) {
		cardDao.addCard(card);
	}
	@Override
	public CardProviceVO selectCard(Map<String, Object> map) {
		return cardDao.selectCard(map);
	}
	@Override
	public void updateCard(Map<String, Object> map) {
		cardDao.updateCard(map);
	}

	@Override
	public List<Card> selectCardForUpdateTime() {
		List<Card> list = cardDao.selectCardForUpdateTime();
		return list;
	}

	@Override
	public void updateCardTime(Map<String, Object> map) {
		cardDao.updateCardTime(map);
		
	}
	
	@Autowired
	public void setFactory(SqlSessionFactory factory) {
		this.cardDao = factory.openSession().getMapper(CardDao.class);
	}
	@Override
	public List<CardVOType> TestselectAllCard(Map<String, Object> map) {
		
		return cardDao.TestselectAllCard(map);
	}
}
