package com.ssm.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Repository;

import com.ssm.dao.BuyDetailDao;
import com.ssm.pojo.BuyDetail;
@Repository
public class BuyDetailDaoImpl implements BuyDetailDao {
	private BuyDetailDao buyDetailDao;
	public Integer selectBuyNumBygameName(String gameName,String userName) {
		return buyDetailDao.selectBuyNumBygameName(gameName, userName);
	}
	
	public void addbuyDetail(Map<String, Object> map3) {
		buyDetailDao.addbuyDetail(map3);
	}


	public void updatedownloadNum(Map<String, Object> map4) {
		buyDetailDao.updatedownloadNum(map4);
	}

	public void updatedownloadNums(Map<String, Object> map5) {
		buyDetailDao.updatedownloadNums(map5);
	}
	public void updatedownloadNums1(Map<String, Object> map6) {
		buyDetailDao.updatedownloadNums1(map6);
	}
	public List<BuyDetail> selectBuyDetailByPage(Map<String, Object> map) {
		return buyDetailDao.selectBuyDetailByPage(map);
	}

	public Integer countBuyDetailByCond(Map<String, Object> map) {
		return buyDetailDao.countBuyDetailByCond(map);
	}
	public String selectLatestTimeBygameName(String gameName, String userName) {
		return buyDetailDao.selectLatestTimeBygameName(gameName, userName);
	}
	public void overtimeupdate(Map<String, Object> map5) {
		buyDetailDao.overtimeupdate(map5);
	}
	public void updateGameNameByGameName(String newGameName, String oldGameName) {
		buyDetailDao.updateGameNameByGameName(newGameName, oldGameName);
	}
//	=====================================
	public void setFactory(SqlSessionFactory factory) {
		this.buyDetailDao = factory.openSession().getMapper(BuyDetailDao.class);
	}









}
