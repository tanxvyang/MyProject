package com.ssm.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssm.dao.ProvinceDao;
import com.ssm.pojo.Province;
@Repository
public class ProvinceDaoImpl implements ProvinceDao{
private ProvinceDao provinceDao;

public Province findProByName(String pro) {
	return provinceDao.findProByName(pro);
}

public List<Province> getAllProvince() {
	return provinceDao.getAllProvince();
}

}
