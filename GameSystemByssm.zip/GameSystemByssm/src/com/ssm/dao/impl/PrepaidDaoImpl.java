package com.ssm.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssm.dao.PrepaidDao;
import com.ssm.pojo.Prepaid;
@Repository
public class PrepaidDaoImpl implements PrepaidDao{
	
	private PrepaidDao prepaidDao;
	@Override
	public List<Prepaid> selectPrepaidByPrepUserName(String prepUserName) {
		List<Prepaid> prepaid =  prepaidDao.selectPrepaidByPrepUserName(prepUserName);
		return prepaid;
	}
	
	
	@Autowired
	public void setFactory(SqlSessionFactory factory) {
		this.prepaidDao = factory.openSession().getMapper(PrepaidDao.class);
	}


//	public void recharge(Map<String, Object> map) {
//		prepaidDao.recharge(map);
//	}

	@Override
	public void addPrepaid(Prepaid prepaid) {
		prepaidDao.addPrepaid(prepaid);
	}


}
