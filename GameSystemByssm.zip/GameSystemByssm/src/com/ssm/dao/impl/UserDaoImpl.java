package com.ssm.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssm.dao.UserDao;
import com.ssm.pojo.User;
@Repository
public class UserDaoImpl implements UserDao {
	private UserDao userDao; 
	@Override
	public User selectUserByNP(String userName, String userPwd) {
		return userDao.selectUserByNP(userName, userPwd);
	}

	@Override
	public User selectUserByName(String userName) {
		return userDao.selectUserByName(userName);
	}

	@Override
	public List<User> selectUserByCondAndPage(Map<String, Object> map) {
		return userDao.selectUserByCondAndPage(map);
	}

	@Override
	public Integer countUser(Map<String, Object> map) {
		return userDao.countUser(map);
	}

	

	@Override
	public void addUser(User user) {
		userDao.addUser(user);
	}

	@Override
	public void updataStatus(Map<String, Object> map) {
		userDao.updataStatus(map);
		
	}

	@Override
	public User selectUserById(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return userDao.selectUserById(map);
	}

	@Override
	public void updateRMBByuserId(Map<String, Object> map) {
		userDao.updateRMBByuserId(map);
		
	}
//修改金币+游币
	@Override
	public void updateSercurityByuserId(Map<String, Object> map1) {
		userDao.updateSercurityByuserId(map1);	
	}
	//修改金币
	@Override
	public void updateSercuritysByuserId(Map<String, Object> map2) {
		userDao.updateSercuritysByuserId(map2);
		
	}
	@Autowired
	public void setFactory(SqlSessionFactory factory) {
		this.userDao = factory.openSession().getMapper(UserDao.class);
	}

	@Override
	public void RechargeByuserId(Map<String, Object> updateSercurity) {
		userDao.RechargeByuserId(updateSercurity);
		
	}

	@Override
	public void updatePwd(String pwd, String userName) {
		userDao.updatePwd(pwd,userName);
		
	}

	@Override
	public User selectUserPhone(String UserPhone) {
		return userDao.selectUserPhone(UserPhone);
	}
}
