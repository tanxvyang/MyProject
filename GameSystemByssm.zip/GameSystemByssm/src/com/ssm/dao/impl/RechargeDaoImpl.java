package com.ssm.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Repository;

import com.ssm.dao.CardDao;
import com.ssm.dao.RechargeDao;
import com.ssm.pojo.Recharge;
@Repository
public class RechargeDaoImpl implements RechargeDao{
	private RechargeDao rechargeDao;
	public void insertRecharge(Map<String, Object> rechargeMap) {
		rechargeDao.insertRecharge(rechargeMap);
	}
	public Integer countRechargeDaoByCond(Map<String, Object> map) {
		return rechargeDao.countRechargeDaoByCond(map);
	}
	public List<Recharge> selectRechargeByPage(Map<String, Object> map) {
		return rechargeDao.selectRechargeByPage(map);
	}
//	=====================================
	public void setFactory(SqlSessionFactory factory) {
		this.rechargeDao = factory.openSession().getMapper(RechargeDao.class);
	}

}
