package com.ssm.dao.impl;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssm.dao.StudentDao;
import com.ssm.dao.UserManagerDao;
import com.ssm.pojo.UserManager;
@Repository
public class UserManagerDaoImpl implements UserManagerDao {
	
	private UserManagerDao  userManagerDao;
	@Override
	public UserManager selectUserManagerByNP(String rootName, String rootPasseword) {
		System.out.println("userManagerDao" + rootName);
		System.out.println("userManagerDao" + rootPasseword);
		return userManagerDao.selectUserManagerByNP(rootName, rootPasseword);
	}
	

	@Override
	public UserManager selectUserManagerByName(String rootName) {
		
		return userManagerDao.selectUserManagerByName(rootName);
	}
	


	
	
	@Autowired
	public void setFactory(SqlSessionFactory factory) {
		this.userManagerDao = factory.openSession().getMapper(UserManagerDao.class);
	}
}
