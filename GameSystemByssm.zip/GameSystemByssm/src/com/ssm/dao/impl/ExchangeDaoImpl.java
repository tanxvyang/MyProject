package com.ssm.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssm.dao.ExchangeDao;
import com.ssm.pojo.Exchange;
import com.ssm.pojo.vo.ExchangeProviceVO;

@Repository
public class ExchangeDaoImpl implements ExchangeDao{
	
	
	private ExchangeDao exchangeDao;
	@Override
	public Integer countExchange(Map<String, Object> map) {
		Integer count = exchangeDao.countExchange(map);
		return count;
	}
	@Override
	public List<ExchangeProviceVO> selectAllExchange(Map<String, Object> map) {
		List<ExchangeProviceVO> exchanges = exchangeDao.selectAllExchange(map);
		return exchanges;
	}
	
	@Autowired
	public void setFactory(SqlSessionFactory factory) {
		this.exchangeDao = factory.openSession().getMapper(ExchangeDao.class);
	}
	@Override
	public void deleExchange(Integer exchangeid) {
		exchangeDao.deleExchange(exchangeid);
	}
	@Override
	public ExchangeProviceVO selectGameByExchangeName(Integer exchangeid) {
		return exchangeDao.selectGameByExchangeName(exchangeid);
	}
	@Override
	public void updateExchange(Map<String, Object> map) {
		exchangeDao.updateExchange(map);
	}
	@Override
	public Exchange selectExchangeByExchangeName(String exchangeCity) {
		return exchangeDao.selectExchangeByExchangeName(exchangeCity);
	}
	@Override
	public void addExchange(Exchange exchange) {
		exchangeDao.addExchange(exchange);
	}

}
