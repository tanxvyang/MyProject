package com.ssm.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssm.dao.GameTypeDao;
import com.ssm.pojo.GameType;
@Repository
public class GameTypeDaoImpl implements GameTypeDao {
 private GameTypeDao gameTypeDao;
	@Override
	public Integer countGameType(Map<String, Object> map) {
		Integer count = gameTypeDao.countGameType(map);
		return count;
	}
	@Override
	public List<GameType> selectAllGameType(Map<String, Object> map) {
		List<GameType> gameTypes = gameTypeDao.selectAllGameType(map);
		return gameTypes;
	}

	@Override
	public void deleGameType(String typeName) {
		gameTypeDao.deleGameType(typeName);

	}

	@Override
	public void updateType(Map<String, Object> map) {
		gameTypeDao.updateType(map);

	}

	@Override
	public void addGameType(GameType gameType) {
		gameTypeDao.addGameType(gameType);

	}

	@Override
	public GameType selectTypeByName(String typeName) {
		return gameTypeDao.selectTypeByName(typeName);
	}

	@Override
	public List<GameType> selectType() {
		return gameTypeDao.selectType();
	}
	
	@Autowired
	public void setFactory(SqlSessionFactory factory) {
		this.gameTypeDao = factory.openSession().getMapper(GameTypeDao.class);
	}
	@Override
	public GameType selectTypeById(Integer id) {
		// TODO Auto-generated method stub
		return gameTypeDao.selectTypeById(id);
	}

}
