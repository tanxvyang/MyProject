package com.ssm.dao;

import com.ssm.pojo.UserManager;

public interface UserManagerDao {

 public	 UserManager selectUserManagerByNP(String rootName, String rootPasseword);
 public	 UserManager selectUserManagerByName(String rootName);

}
