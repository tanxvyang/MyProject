package com.ssm.dao;

import java.util.List;
import java.util.Map;

import com.ssm.pojo.Exchange;
import com.ssm.pojo.vo.ExchangeProviceVO;

public interface ExchangeDao {
	public Integer countExchange(Map<String, Object> map);

	public List<ExchangeProviceVO> selectAllExchange(Map<String, Object> map);

	public void deleExchange(Integer exchangeid);

	public ExchangeProviceVO selectGameByExchangeName(Integer exchangeid);

	public void updateExchange(Map<String, Object> map);

	public Exchange selectExchangeByExchangeName(String exchangeCity);

	public void addExchange(Exchange exchange);
}
