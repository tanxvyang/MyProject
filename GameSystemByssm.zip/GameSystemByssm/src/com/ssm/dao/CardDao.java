package com.ssm.dao;

import java.util.List;
import java.util.Map;

import com.ssm.pojo.Card;
import com.ssm.pojo.vo.CardProviceVO;
import com.ssm.pojo.vo.CardVOType;


public interface CardDao {

	public List<CardProviceVO> selectAllCard(Map<String, Object> map);
	public List<CardVOType> TestselectAllCard(Map<String, Object> map);

	public void addCard(Card card);
	
	public CardProviceVO selectCard(Map<String, Object> map);
	
	public void updateCard(Map<String, Object> map);

	public Integer countCard(Map<String, Object> map);

	public List<Card> selectCardForUpdateTime();

	public void updateCardTime(Map<String, Object> map);
}
