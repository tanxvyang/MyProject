package com.ssm.dao;

import java.util.List;
import java.util.Map;

import com.ssm.pojo.BuyDetail;

public interface BuyDetailDao {

	public Integer selectBuyNumBygameName(String gameName,String userName);
	//第一次购买，添加信息
	public void addbuyDetail(Map<String, Object> map3);
	//下载三次后，将次数改为1
	public void updatedownloadNum(Map<String, Object> map4);
	//下载第2，3次时，修改次数
	public void updatedownloadNums(Map<String, Object> map5);
	public void updatedownloadNums1(Map<String, Object> map6);
	//得到游戏记录，分页操作
	public List<BuyDetail> selectBuyDetailByPage(Map<String, Object> map);
	public Integer countBuyDetailByCond(Map<String, Object> map);
//	超过24小时，下载次数为3
	public String selectLatestTimeBygameName(String gameName, String userName);
	public void overtimeupdate(Map<String, Object> map5);
	//当游戏名字修改后，购买记录中的名字也需要修改
	public void updateGameNameByGameName(String newGameName, String oldGameName);

}
