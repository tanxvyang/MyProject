package com.ssm.dao;

import java.util.List;

import com.ssm.pojo.Prepaid;

public interface PrepaidDao {
	public List<Prepaid> selectPrepaidByPrepUserName(String prepUserName);
	
	
	//public void recharge(Map<String, Object> map);


	public void addPrepaid(Prepaid prepaid);
	
	
}
