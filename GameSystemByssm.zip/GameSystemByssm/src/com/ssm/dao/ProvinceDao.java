package com.ssm.dao;

import java.util.List;

import com.ssm.pojo.Province;

public interface ProvinceDao {
public Province findProByName(String pro);
public List<Province> getAllProvince();


}
