package com.ssm.exception;

public class AddCardException extends Exception {

	public AddCardException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AddCardException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AddCardException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AddCardException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
