package com.ssm.exception;

public class downloadException extends Exception {

	public downloadException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public downloadException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public downloadException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public downloadException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
