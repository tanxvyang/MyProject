package com.ssm.exception;

public class LogineException extends Exception {

	public LogineException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LogineException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public LogineException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public LogineException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
