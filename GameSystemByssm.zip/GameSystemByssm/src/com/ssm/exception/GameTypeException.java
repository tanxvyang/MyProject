package com.ssm.exception;

public class GameTypeException extends Exception {

	public GameTypeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GameTypeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public GameTypeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public GameTypeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
