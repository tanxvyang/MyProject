package com.ssm.exception;

public class deleteGameException extends Exception {

	public deleteGameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public deleteGameException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public deleteGameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public deleteGameException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
