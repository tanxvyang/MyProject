package com.ssm.util;

public interface Constants {
	public static final Integer PAGE_SIZE_4 = 4;
	public static final int PAGE_SIZE_5 = 5;
	public static final int PAGE_SIZE_1 = 1;
}
