package com.ssm.test;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.exception.GameTypeException;
import com.ssm.pojo.vo.ExchangeProviceVO;
import com.ssm.service.ExchangeService;
import com.ssm.service.impl.ExchangeServiceImpl;

public class TestExchange {
	ApplicationContext context ;
	@Before
	public void berforContext(){
		context = new ClassPathXmlApplicationContext("applicationContext.xml");
	}
	
	@Test
	public void testPager() throws GameTypeException{
		ExchangeService exchangeService = context.getBean(ExchangeServiceImpl.class);
		
		
		try {
			System.out.println(exchangeService.selectExchangeByExchangeName("28").toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		/*Map<String, Object> map2 = new HashMap<String, Object>();
		
		map2.put("pageNo", 1);
		map2.put("pageSize",4);
		map2.put("exchangeCity", 28);
		
		try {
			System.out.println(exchangeService.selectAllExchange(map2).getList().get(0));
			ExchangeProviceVO exchangeProviceVO=  exchangeService.selectAllExchange(map2).getList().get(0);
			
			System.out.println(exchangeProviceVO.getExchangeCity());
			System.out.println(exchangeProviceVO.getExchange().getExchangeCreateTime());
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		
		
		
		
		
//		GameTypeDao dao = context.getBean(GameTypeDaoImpl.class);
//		Map<String, Object> map2 = new HashMap<String, Object>();
//		
//		map2.put("pageNo", 1);
//		map2.put("pageSize",4);
//		map2.put("typeName", null);
//		map2.put("typeStatus", null);
//		System.out.println(	dao.countGameType(map2));
//		dao.selectAllGameType(map2);
		
//		GameTypeService service = context.getBean(GameTypeService.class);
////		Pager<GameType> pager =  service.selectAllGameType(1,null,null);
////		System.out.println("页数:"+pager.getList().size());
////		
//		service.deleGameType("棋牌游戏");
				
	}
	

}
