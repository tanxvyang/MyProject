package com.ssm.test;

import org.junit.Before;
import org.junit.Test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.exception.LogineException;
import com.ssm.pojo.User;
import com.ssm.pojo.UserManager;
import com.ssm.service.StudentService;
import com.ssm.service.UserManagerService;
import com.ssm.service.UserService;
import com.ssm.util.Pager;


public class TestUser {

	ApplicationContext context ;
	
	
	
	/**
	 * 管理员用户登录测试
	 * @param args
	/**
	
	
	public static void main(String[] args) {
		ApplicationContext	context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		System.out.println(context);
		
		
		
		
		
//		UserManagerService userManagerService = context.getBean(UserManagerService.class);
//		UserManager manager;
//		try {
//			manager = userManagerService.login("user001", "user001");
//			System.out.println(manager);
//		} catch (LogineException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
	}
	@Test
	public void TestUser(){
		System.out.println(context);
		UserManagerService userManagerService = context.getBean("UserManagerService",UserManagerService.class);
		try {
			UserManager manager = userManagerService.login("user001", "user001");
			System.out.println(manager);
		} catch (LogineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	
	 
	 */
	
	@Before
	public void berforContext(){
		context = new ClassPathXmlApplicationContext("applicationContext.xml");
	}
	
	
	
	@Test
	public void TestUser(){
		UserService service = context.getBean(UserService.class);
		//分页
//		Pager<User> pager =  service.getUserByPage(1, null, null);
//		System.out.println(pager.getList().size());
//				System.out.println(pager.getList().get(0).getUserCreateTime());
		
		try {
			service.modifyUserStatus(2,"41,1,21,22");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	
	
	
	
	
	
}
