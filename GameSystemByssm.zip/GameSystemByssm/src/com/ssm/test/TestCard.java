package com.ssm.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.dao.CardDao;
import com.ssm.dao.impl.CardDaoImpl;
import com.ssm.pojo.vo.CardProviceVO;
import com.ssm.pojo.vo.CardVOType;
import com.ssm.service.CardService;
import com.ssm.util.Pager;

public class TestCard {
	ApplicationContext context ;
	@Before
	public void berforContext(){
		context = new ClassPathXmlApplicationContext("applicationContext.xml");
	}
	@Test
	public void selectAll(){
		
		CardService cardService  =  context.getBean(CardService.class);
//		CardDao cardDao = context.getBean(CardDaoImpl.class);
//		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("cardNumber",null );
		map.put("cardStartTime",null );
		map.put("cardEndTime",null );
		map.put("cardCity",null );
		map.put("pageNo", 1);
		map.put("pageSize", 4);
//		
//		List<CardVOType> cardVOTypes = cardDao.TestselectAllCard(map);
//		System.out.println(cardVOTypes.size()+"=====================================");
//		for (CardVOType cardVOType : cardVOTypes) {
//			System.out.println(cardVOType.toString());
//		}
		
		
		try {
			Pager<CardVOType> cardProviceVOs = cardService.selectAllCard(map);
			System.out.println(cardProviceVOs.getList().size());
			List<CardVOType> cardProviceVOs2=cardProviceVOs.getList();
			for (CardVOType cardProviceVO : cardProviceVOs2) {
//				System.out.println(cardProviceVO.getCardCity());
//				System.out.println(cardProviceVO.toString());
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
