package com.ssm.test;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.dao.GameTypeDao;
import com.ssm.dao.impl.GameTypeDaoImpl;
import com.ssm.exception.GameTypeException;
import com.ssm.pojo.GameType;
import com.ssm.pojo.vo.CardProviceVO;
import com.ssm.service.CardService;
import com.ssm.service.GameTypeService;
import com.ssm.util.Pager;

public class TestGameType {
	ApplicationContext context ;
	@Before
	public void berforContext(){
		context = new ClassPathXmlApplicationContext("applicationContext.xml");
	}
	
	@Test
	public void testPager() throws GameTypeException{
//		GameTypeDao dao = context.getBean(GameTypeDaoImpl.class);
//		GameType gameType = new GameType();
//		gameType.setTypeName("棋牌类");
//		gameType.setTypePicture("a.jpg");
//		gameType.setTypeStatus("2");
//		dao.addGameType(gameType);
//		Map<String, Object> map2 = new HashMap<String, Object>();
//		
//		map2.put("pageNo", 1);
//		map2.put("pageSize",4);
//		map2.put("typeName", null);
//		map2.put("typeStatus", null);
//		System.out.println(	dao.countGameType(map2));
//		dao.selectAllGameType(map2);
		
		//GameTypeService service = context.getBean(GameTypeService.class);
//		Pager<GameType> pager =  service.selectAllGameType(1,null,null);
//		System.out.println("页数:"+pager.getList().size());
		
		//service.deleGameType("情侣类");
		
//		CardService cardService =  context.getBean(CardService.class);
//		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("cardNumber",null );
//		map.put("cardStartTime",null );
//		map.put("cardEndTime",null );
//		map.put("cardCity", null);
//		map.put("pageNo", 1);
//		try {
//		Pager<CardProviceVO> sys=cardService.selectAllCard(map);
//			System.out.println(sys.getList().size());
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
				
	}
	
	
	
	
	
}
