package com.ssm.controller;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssm.pojo.Province;
import com.ssm.service.ProvinceService;

@Controller
@RequestMapping("/province")
public class ProvinceController {
@Autowired
private ProvinceService provinceService;
@RequestMapping("/getAllProvince")
public ModelAndView getAllProvince(HttpServletResponse resp){
	ModelAndView mv = new ModelAndView();
	List<Province> provinces = provinceService.getAllProvince();
	try{
		PrintWriter out = resp.getWriter();
		out.write(JSONArray.fromObject(provinces).toString());
		out.flush();
		out.close();
		mv.setViewName("/user/register.jsp");
	}catch (Exception e) {
		e.printStackTrace();
	}
	return mv;
}




}
