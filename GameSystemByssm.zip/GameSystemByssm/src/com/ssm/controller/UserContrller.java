package com.ssm.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssm.exception.LogineException;
import com.ssm.exception.RegistException;
import com.ssm.pojo.User;
import com.ssm.service.CardService;
import com.ssm.service.UserService;
import com.ssm.util.Pager;

@Controller
@RequestMapping("/user")
public class UserContrller {
	@Autowired
	private UserService userService;
	@Autowired
	private CardService cardService;
	
	@RequestMapping("/login")
	public ModelAndView login(String username,String password,HttpServletRequest request){
		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession();
	try{
			User user = userService.login(username,password);
			session.setAttribute("user", user);
			mv.addObject("user", user);
			mv.setViewName("/user/portal.jsp");
			return mv;
			
		} catch (LogineException e) {
			request.setAttribute( "username", username );// 保存输入的用户名
			request.setAttribute( "passeword", password );// 保存输入的密码
			mv.addObject("isError", true);
			mv.addObject("errorMessage", e.getMessage());
			mv.setViewName("/user/login.jsp");
			return mv;
		}
	}	
	
	
	
	
	@RequestMapping("/regist")
	public ModelAndView regist(String username,String pwd,String iphone,String sex,String birthday,String location,HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		User user = new User();
		user.setUserName(username);
		user.setUserPwd(pwd);
		user.setUserPhone(iphone);
		user.setUserSex(Integer.valueOf(sex));
		user.setUserBirthday(birthday);
		user.setUserCity(location);
		user.setUserCardamount(100);
		user.setUserCurrency(100);
		user.setUserTariffe(100.00);
		user.setUserStatus(1);
		try {
			userService.regist(user);
			mv.setViewName("/user/login.jsp");
			return mv;
		} catch (RegistException e) {
			e.printStackTrace();
			request.setAttribute( "user", user );// 保存输入的内容
			mv.addObject("isError", true);
			mv.addObject("errorMessage", e.getMessage());
			mv.setViewName("/user/register.jsp");
			return mv;
		}
	}
	
	
	@RequestMapping("/modifyUserStatus")//ajax方式传值并返回json格式
	public void modifyUserStatus(HttpServletRequest request, HttpServletResponse response ) {
		
		Integer Status = Integer.valueOf(request.getParameter("Status"));
		String chooseUser = request.getParameter("userIdArray").toString();
		PrintWriter out;
		try {
			userService.modifyUserStatus(Status,chooseUser);
			out = response.getWriter();
			out.write("true");
		    out.flush();
		    out.close();
		} catch (Exception e) {
			
		}
		
	}
	@RequestMapping("/getUserByPage")//ajax方式传值并返回json格式
	public void getUserByPage(HttpServletRequest request, HttpServletResponse response ) {
	
		Integer pageNo = Integer.valueOf(request.getParameter("pageNo"));
		String username = request.getParameter("username");
		String userPhone = request.getParameter("iphone");
			PrintWriter out;
			try {
				Pager<User> pager  = userService.getUserByPage(pageNo,username,userPhone);
			out = response.getWriter();
			
			/**
			 * 原因是json 的日期类型转换问题,要通过重写get方法解决
			 * 
			 * 
			 * at net.sf.json.JSONObject._fromBean(JSONObject.java:737)
	... 48 more
Caused by: java.lang.IllegalArgumentException
	at java.sql.Date.getHours(Date.java:143)
	... 58 more
			 */
			String json = JSONObject.fromObject(pager).toString();
			out.write(json);
			out.flush();
			out.close();
	
			} catch (IOException e) {
				e.printStackTrace();
			}
	
	}
	@RequestMapping("/getUserMessage")//ajax方式传值并返回json格式
	public void getUserMessage(HttpServletRequest request, HttpServletResponse response ) {
		
		String username = request.getParameter("username");
		PrintWriter out;
		try {
			User user = userService.getUserMessage(username);
			out = response.getWriter();
			String json = JSONObject.fromObject(user).toString();
			out.write(json);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	//充值
		@RequestMapping("/chargeMoney")
		public String chargeMoney(HttpServletRequest request,HttpServletResponse response){
			String cardNumber = request.getParameter("cardNumber");
			String cardPwd = request.getParameter("cardPwd");
			String userName = request.getParameter("userName");
			PrintWriter out;
			try {
				//更新密保卡状态
				cardService.updateCardTime();
				userService.addMoney(cardNumber,cardPwd,userName);
				out = response.getWriter();
				out.write("true");
				out.flush();
				out.close();
			} catch (Exception e) {
				try {
					out = response.getWriter();
					out.write(e.getMessage());
					out.flush();
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
			}
			return "success";
		}
		
		//修改密码
		@RequestMapping("/updatePwd")
		public void updatePwd(HttpServletRequest request, HttpServletResponse response){
			String Pwd = request.getParameter("Pwd");
			String userName = request.getParameter("userName");
			PrintWriter out;
			try {
				userService.updatePwd(Pwd,userName);
				out = response.getWriter();
				out.write("true");
				out.flush();
				out.close();
			} catch (IOException e) {
			}
			request.getSession().removeAttribute("user");
		}
		
		//退出系统
		@RequestMapping("/exitSys")
		public void exitSys(HttpServletRequest request, HttpServletResponse response){
			request.getSession().removeAttribute("user");
			PrintWriter out;
			try {
				out = response.getWriter();
				out.write("true");
				out.flush();
				out.close();
			} catch (Exception e) {
				e.printStackTrace();
				
				}
		}
	
	
}
