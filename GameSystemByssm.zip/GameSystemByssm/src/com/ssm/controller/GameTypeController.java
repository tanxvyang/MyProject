package com.ssm.controller;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ssm.exception.GameTypeException;
import com.ssm.pojo.GameType;
import com.ssm.service.GameTypeService;
import com.ssm.util.Pager;

@Controller
@RequestMapping("/gameType")
public class GameTypeController {
 @Autowired
	private  GameTypeService gameTypeService;
 @RequestMapping("/selectAllGameType")
 public void  selectAllGameType(HttpServletRequest request, HttpServletResponse response ){
		Integer pageNo = Integer.valueOf(request.getParameter("pageNo"));
		String typeName = request.getParameter("typeName");
		String typeStatus = request.getParameter("typeStatus");
		try {
			PrintWriter out;
			Pager<GameType>  pager =  gameTypeService.selectAllGameType(pageNo,typeName,typeStatus);
			out = response.getWriter();
			String json = JSONObject.fromObject(pager).toString();
			out.write(json);
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

 }
 
 
 /**
 * 
  * @param imgFile
  * @param request
  * @param response
  */
	@RequestMapping("/addGameType")
	public ModelAndView addGameType(@RequestParam("imgFile") CommonsMultipartFile imgFile,HttpServletRequest request,HttpServletResponse response){
		ModelAndView mv = new ModelAndView();
		String newName = request.getParameter("newtypeName");
		String status = request.getParameter("newtypeStatus");
//		String imgfile = request.getParameter(imgFile.getFileItem().getName());
		String imgPath = request.getSession().getServletContext().getRealPath("/img");
		String fileName = imgFile.getFileItem().getName();
		String suffix = "";
		if(!fileName.equals("")) {
			suffix = fileName.substring(fileName.indexOf('.'), fileName.length());
		}
		
		GameType gameType = new GameType();
		gameType.setTypeName(request.getParameter("newtypeName"));
		gameType.setTypeStatus(request.getParameter("newtypeStatus"));
		try {
			gameTypeService.addGameType(gameType, imgFile.getInputStream(), imgPath, suffix,fileName);
			mv.setViewName("/gameType/gametype.jsp");
			return mv;
		} catch (Exception e) {
			mv.addObject("isError", true);
			mv.addObject("errorMessage", e.getMessage());
			mv.setViewName("/gameType/addGameType.jsp");
			return mv;
		}
	}
	
	@RequestMapping("/deleGameType")
	public void deleGameType(HttpServletRequest request, HttpServletResponse response){
		String typeName = request.getParameter("typeName").toString();
		System.out.println("选中"+typeName);
		PrintWriter out;
		try {
			gameTypeService.deleGameType(typeName);
			out = response.getWriter();
			out.write("true");
			out.flush();
			out.close();
		} catch (Exception e) {
		
		}
	}
	
	@RequestMapping("/getGameTypeById")
	public String getGameTypeByname(HttpServletRequest request, HttpServletResponse response){
		Integer id =  Integer.valueOf(request.getParameter("Id"));
		System.out.println(id);
		GameType gameType ;
		try {
			 gameType = gameTypeService.selectGameTypeById(id);
			 request.setAttribute("gameType", gameType);
		} catch (GameTypeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "/gameType/updateGameType.jsp";
	}
	
	@RequestMapping("/updateType")
	public ModelAndView updateType(String typeName,Integer ID,String typeStatus,HttpServletRequest request, HttpServletResponse response){
		ModelAndView mv = new ModelAndView();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("typeName",typeName );
		map.put("ID",ID );
		map.put("typeStatus",typeStatus );
		try {
			gameTypeService.updateType(map);
			
		} catch (Exception e) {
		GameType gameType;
		try {
			gameType = gameTypeService.selectGameTypeById(ID);
			request.setAttribute("gameType", gameType);
		} catch (GameTypeException e1) {
			
		}
			mv.addObject("isError", true);
			mv.addObject("errorMessage", e.getMessage());
			
			mv.setViewName("/gameType/updateGameType.jsp");
			return mv;
		}
		mv.setViewName("/gameType/gametype.jsp");
		return mv;
		
	}
	
	@RequestMapping("/selectGameTypeByTypeName")
	public void selectGameTypeByTypeName(HttpServletRequest request, HttpServletResponse response){
		String typeName = request.getParameter("typeName");
		PrintWriter out;
		try {
			GameType gameType = gameTypeService.selectGameTypeByTypeName(typeName);
			out = response.getWriter();
			if(gameType != null){
				out.write("true");
			}
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	@RequestMapping("/selectType")
	public void selectType(HttpServletRequest request, HttpServletResponse response){
		try {
			List<GameType> list =  gameTypeService.selectType();
			PrintWriter out;
			out = response.getWriter();
			String json = JSONArray.fromObject(list).toString();
			out.write(json);
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
 
}
	}
