package com.ssm.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.exception.downloadException;
import com.ssm.pojo.BuyDetail;
import com.ssm.service.BuyDetailService;
import com.ssm.service.GameService;
import com.ssm.util.Pager;

@Controller
@RequestMapping("/buyDetail")
public class BuyDetailController {
	@Autowired
	private BuyDetailService buyDetailService;
	@Autowired
	private GameService gameService;
	@RequestMapping("/buyGame")
	public void buyGame(HttpServletRequest request,HttpServletResponse response){
		String gameName = request.getParameter("gameName");
		String userName = request.getParameter("userName");
		String buyWay = request.getParameter("buyWay");
		PrintWriter out;
		try {
			Integer num = buyDetailService.addGame(gameName,userName,buyWay);
			out = response.getWriter();
			if(num==null){
				out.write("null");
			}else if(num == 1){
				out.write("1");
				
			}else if(num == 2){
				out.write("2");
				
			}else if(num == 3){
				out.write("3");
			}else if(num == 4){
				out.write("4");
			}
			out.flush();
			out.close();
		} catch (Exception e) {
			try {
				out = response.getWriter();
				out.write(e.getMessage());
				out.flush();
				out.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}
	@RequestMapping("/getGameMessage")
	public void getGameMessage(HttpServletRequest request,HttpServletResponse response){
		String gameName = request.getParameter("gameName");
		String userName = request.getParameter("userName");
		PrintWriter out;
		try {
			Integer num = buyDetailService.getGameMessage(gameName,userName);
			out = response.getWriter();
			if(num==null){
				out.write("null");
			}else if(num == 1){
				out.write("1");
				
			}else if(num == 2){
				out.write("2");
				
			}else if(num == 3){
				out.write("3");
			}
			else if(num == 4){
				out.write("4");
			}
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@RequestMapping("/download")
	public void download(Integer Id,HttpServletRequest request,HttpServletResponse response) throws Exception{
		String gameName =new String( request.getParameter("name").getBytes("ISO-8859-1"),"UTF-8");
			System.out.println("下载的游戏名为================================="+gameName);
		String a = "/img/";
		String b = a.concat(gameName);
		String tomcatTxt = b.concat(".txt");
		//通过request获取文件地址
		String webRootPath = request.getSession().getServletContext().getRealPath(tomcatTxt);
		
		
		File f = new File(webRootPath);
		//设置返回类型是文件类型
		response.setContentType("application/octet-stream");
		//设置返回文件的文件名字
		String fi = "attachment;filename=";
		String w = gameName.concat(".txt");
		String name = fi+URLEncoder.encode(w, "UTF-8");
		
		response.setHeader("content-disposition", name);
//		从response中获取字节输出流
		try {
			OutputStream ops = response.getOutputStream();
		
		//整读文件 fis得到还剩多少字节没有读取
		FileInputStream fis = new FileInputStream(f);
		byte[] bs = new byte[fis.available()];
		fis.read(bs);
		fis.close();
		//整写文件
		ops.write(bs);
		ops.flush();
		ops.close();
		} catch (Exception e) {
			throw new downloadException("未找到游戏文件,无法下载!");
		}
		
		
	}
	
	@RequestMapping("/getBuyDetailByPager")
	public void getBuyDetailByPager(HttpServletRequest request,HttpServletResponse response){
		Integer pageNo = Integer.parseInt(request.getParameter("pageNo"));
		String userName = request.getParameter("userName");
		Pager<BuyDetail> pager = buyDetailService.getBuyDetailByPager(pageNo, userName);
			PrintWriter out;
			try {
				out = response.getWriter();
				String json = JSONObject.fromObject(pager).toString();
				out.write(json);
				out.flush();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	
	
	@RequestMapping("/overtime")
	public void overtime(HttpServletRequest request,HttpServletResponse response) throws Exception{
		String gameName = request.getParameter("gameName");
		String userName = request.getParameter("userName");
		buyDetailService.overtime(gameName,userName);
	}
}
