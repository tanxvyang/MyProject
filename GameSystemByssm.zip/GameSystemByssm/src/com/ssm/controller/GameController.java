package com.ssm.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ssm.exception.deleteGameException;
import com.ssm.pojo.Game;
import com.ssm.service.GameService;
import com.ssm.util.Pager;

@Controller
@RequestMapping("/game")
public class GameController {
	@Autowired
	private GameService gameService;
	@RequestMapping("/getGameByPager")
	public String getGameByPager(HttpServletRequest request,HttpServletResponse response){
		Integer pageNo = Integer.parseInt(request.getParameter("pageNo"));
		String GameName = request.getParameter("GameName");
		String GameTypeName = request.getParameter("GameTypeName");
		Pager<Game> pager = gameService.getGameByPager(pageNo, GameName, GameTypeName);
			PrintWriter out;
			try {
				out = response.getWriter();
				String json = JSONObject.fromObject(pager).toString();
				out.write(json);
				out.flush();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return "success";
		}
	//用户导航栏上得到的信息
	@RequestMapping("/getGamesByPager")
	public void getGamesByPager(HttpServletRequest request,HttpServletResponse response){
		Integer pageNo = Integer.parseInt(request.getParameter("pageNo"));
		String gameName = "";
		String gameTypeName = request.getParameter("GameTypeName");
		Pager<Game> pager = gameService.getGameByPager(pageNo, gameName, gameTypeName);
		PrintWriter out;
		try {
			out = response.getWriter();
			String json = JSONObject.fromObject(pager).toString();
			out.write(json);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	@RequestMapping("/getGamesBygameTypeName")
	public void getGamesByGameTypeName(HttpServletRequest request,HttpServletResponse response){
		String gameTypeName = request.getParameter("GameTypeName");
		List <Game> list = gameService.getGamesByGameTypeName(gameTypeName);
		PrintWriter out;
		try {
			out = response.getWriter();
			String json = JSONArray.fromObject(list).toString();
			out.write(json);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	@RequestMapping("/deleteGameById")
	public void deleteGameTypeById(HttpServletRequest request,HttpServletResponse response){
		Integer GameId = Integer.parseInt(request.getParameter("GameId"));
		PrintWriter out;
		try {
			    out = response.getWriter();
				gameService.deleteGameById(GameId);
				out.write("true");
				out = response.getWriter();
			    out.flush();
			    out.close();
		} catch (Exception e) {
			try {
				out = response.getWriter();
				out.write("error");
				out.flush();
				out.close();
			} catch (IOException e1) {
			}
		}
	}
	@RequestMapping("/addGame")
	public ModelAndView addGameType(Game game,@RequestParam("imgFile") CommonsMultipartFile imgFile,
			@RequestParam("imgFile1") CommonsMultipartFile imgFile1,
			@RequestParam("imgFile2") CommonsMultipartFile imgFile2,
			@RequestParam("imgFile3") CommonsMultipartFile imgFile3,
			@RequestParam("gametext") CommonsMultipartFile gametext,
			HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		String imgPath = request.getSession().getServletContext().getRealPath("/img");
		String fileName = imgFile.getFileItem().getName();
		String fileName1 = imgFile1.getFileItem().getName();
		String fileName2 = imgFile2.getFileItem().getName();
		String fileName3 = imgFile3.getFileItem().getName();
		String fileName4 = gametext.getFileItem().getName();
		String suffix = "";
		String suffix1 = "";
		String suffix2 = "";
		String suffix3 = "";
		String suffix4 = "";
		if(!fileName.equals("")) {
			suffix = fileName.substring(fileName.indexOf('.'), fileName.length());
		}
		if(!fileName1.equals("")) {
			suffix1 = fileName1.substring(fileName1.indexOf('.'), fileName1.length());
		}
		if(!fileName2.equals("")) {
			suffix2 = fileName2.substring(fileName2.indexOf('.'), fileName2.length());
		}
		if(!fileName3.equals("")) {
			suffix3 = fileName3.substring(fileName3.indexOf('.'), fileName3.length());
		}
		if(!fileName4.equals("")) {
			suffix4 = fileName4.substring(fileName4.indexOf('.'), fileName4.length());
		}
		try {
			gameService.addGame(game, 
					imgFile.getInputStream(), 
					imgFile1.getInputStream(), 
					imgFile2.getInputStream(), 
					imgFile3.getInputStream(), 
					imgPath, 
					suffix,
					suffix1,
					suffix2,
					suffix3,
					suffix4,
					fileName,
					fileName1,
					fileName2,
					fileName3,
					fileName4,gametext.getInputStream()
					);
			
			mv.setViewName("/game/game.jsp");
			return mv;
		} catch (Exception e) {
			e.printStackTrace();
			mv.addObject("isError", true);
			mv.addObject("errMsg", e.getMessage());
			mv.setViewName("/game/addGame.jsp");
			return mv;
		}
	}
	@RequestMapping("/findGameById")
	public ModelAndView findGameById(Integer id) {
		Game game = gameService.findGameById(id);
		ModelAndView mv = new ModelAndView();
		mv.addObject("game", game);
		mv.setViewName("/game/game.jsp");
		return mv;
	}
	//详情
	@RequestMapping("/getGameById")
	public String getGameById(HttpServletRequest request, HttpServletResponse response){
		Integer id = Integer.parseInt(request.getParameter("Id"));
		Game game = gameService.getGameById(id);
		request.setAttribute("game", game);
		return "/game/gameDetails.jsp";

	}
	//修改，将原始数据放入	
	@RequestMapping("/updateGameById")
	public String updateGameById(HttpServletRequest request, HttpServletResponse response){
		Integer id = Integer.parseInt(request.getParameter("Id"));
		Game game = gameService.getGameById(id);
		request.setAttribute("game", game);
		return "/game/updateGame.jsp";
	}
	@RequestMapping("/getGTS")
	public void getGTS(HttpServletRequest request, HttpServletResponse response){
		String gameName = request.getParameter("gameName");
		PrintWriter out;
		try {
			String gts = gameService.getGTS(gameName);
			out = response.getWriter();
			out.write(gts);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping("/updateGames")
	public ModelAndView updateGames(Game game,HttpServletResponse response,
			@RequestParam("imgFile") CommonsMultipartFile imgFile,
			@RequestParam("imgFile1") CommonsMultipartFile imgFile1,
			@RequestParam("imgFile2") CommonsMultipartFile imgFile2,
			@RequestParam("imgFile3") CommonsMultipartFile imgFile3,
			HttpServletRequest request) {
		
		String imgPath = request.getSession().getServletContext().getRealPath("/img");
		String fileName = imgFile.getFileItem().getName();
		String fileName1 = imgFile1.getFileItem().getName();
		String fileName2 = imgFile2.getFileItem().getName();
		String fileName3 = imgFile3.getFileItem().getName();
		String suffix = "";
		String suffix1 = "";
		String suffix2 = "";
		String suffix3 = "";
		if(!fileName.equals("")) {
			suffix = fileName.substring(fileName.indexOf('.'), fileName.length());
		}
		if(!fileName1.equals("")) {
			suffix1 = fileName1.substring(fileName1.indexOf('.'), fileName1.length());
		}
		if(!fileName2.equals("")) {
			suffix2 = fileName2.substring(fileName2.indexOf('.'), fileName2.length());
		}
		if(!fileName3.equals("")) {
			suffix3 = fileName3.substring(fileName3.indexOf('.'), fileName3.length());
		}
		
		try {
//			Id,gamePrice,rmb,gameName,gameTypeName,gameStatus,gameDeveloper,gameNumber,gameSynopsis,gameDetails,time, 
			gameService.updateGames(game,
					imgFile.getInputStream(), 
					imgFile1.getInputStream(), 
					imgFile2.getInputStream(), 
					imgFile3.getInputStream(), 
					imgPath, 
					suffix,
					suffix1,
					suffix2,
					suffix3,
					fileName,
					fileName1,
					fileName2,
					fileName3
					);
			ModelAndView mv = new ModelAndView();
			mv.addObject("game", game);
			mv.setViewName("/game/game.jsp");
			return mv;
		} catch (Exception e) {
			ModelAndView mv = new ModelAndView();
			e.printStackTrace();
			mv.addObject("isError", true);
			mv.addObject("errMsg", e.getMessage());
			mv.setViewName("/game/updateGame.jsp");
			return mv;
		}
	}
	//购买游戏，得到游戏详情：
	//详情
	@RequestMapping("/Detail")
	public String Detail(HttpServletRequest request, HttpServletResponse response){
		Integer id = Integer.parseInt(request.getParameter("Id"));
		Game game = gameService.getGameById(id);
		if (game.getGameStatus().equals("1")) {
			game.setGameStatus("商用");
		}
		request.setAttribute("game", game);
		return "/user/gameDetail.jsp";
	}
	//购买游戏，得到游戏详情：
	//通过滚动页面详情
	@RequestMapping("/Details")
	public String Details(HttpServletRequest request, HttpServletResponse response){
		String gameImg = request.getParameter("gameImg");
		Game game = gameService.getGameByImg(gameImg);
		request.setAttribute("game", game);
		return "/user/gameDetail.jsp";
	}
	//自动滚动页面拿到四个游戏图片
	@RequestMapping("/getsomeGameImg")
	public void getsomeGameImg(HttpServletRequest request,HttpServletResponse response) {
		List<Game> gameImg =  gameService.getsomeGameImg();
		PrintWriter out;
		try {
			out = response.getWriter();
			out.write(JSONArray.fromObject(gameImg).toString());
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
