package com.ssm.controller;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssm.exception.LogineException;
import com.ssm.pojo.Student;
import com.ssm.pojo.UserManager;
import com.ssm.service.UserManagerService;

@Controller
@RequestMapping("/Manager")
public class UserManagerController {
	@Autowired
	private UserManagerService userManagerService;
	
	@RequestMapping("/login.do")
	public ModelAndView login(String rootName,String rootPassword,String code,HttpServletRequest request) {

		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession();
		try  {
			if (!code.equals(session.getAttribute("verificationCode"))) {
				throw new LogineException("验证码错误!");
			}
			UserManager userManager = userManagerService.login(rootName,rootPassword);
			session.setAttribute("userManager", userManager);
			mv.addObject("userManager", userManager);
			mv.setViewName("/index.jsp");
			return mv;
			
		} catch (LogineException e) {
			e.printStackTrace();
			request.setAttribute( "rootName", rootName );// 保存输入的用户名
			request.setAttribute( "rootPassword", rootPassword );// 保存输入的密码
			mv.addObject("isError",true);
			mv.addObject("errorMessage", e.getMessage());
			mv.setViewName("/login.jsp");
			return mv;
		}
	}
	
	//退出系统
			@RequestMapping("/exitSys")
			public void exitSys(HttpServletRequest request, HttpServletResponse response){
				request.getSession().removeAttribute("userManager");
				PrintWriter out;
				try {
					out = response.getWriter();
					out.write("true");
					out.flush();
					out.close();
				} catch (Exception e) {
					e.printStackTrace();
					
					}
			}

}
