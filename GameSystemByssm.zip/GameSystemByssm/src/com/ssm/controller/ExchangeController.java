package com.ssm.controller;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssm.pojo.Exchange;
import com.ssm.pojo.vo.ExchangeProviceVO;
import com.ssm.service.ExchangeService;
import com.ssm.util.Pager;

@Controller
@RequestMapping("/exchange")
public class ExchangeController {
	@Autowired
	private  ExchangeService exchangeService;
	
	@RequestMapping("/selectAllExchange")
	public void selectAllExchange(HttpServletRequest request, HttpServletResponse response ){
		Integer pageNo = Integer.valueOf(request.getParameter("pageNo"));
		String exchangeCity = request.getParameter("exchangeCity");
		Integer exchangeCityid;
		if (exchangeCity !=null && exchangeCity != "" ) {
			exchangeCityid = Integer.valueOf(request.getParameter("exchangeCity"));
			}else{
				exchangeCityid = null;
			}
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("exchangeCity",exchangeCityid );
		map.put("pageNo", pageNo);
		try {
			PrintWriter out;
			Pager<ExchangeProviceVO>  list =  exchangeService.selectAllExchange(map);
			out = response.getWriter();
			String json = JSONObject.fromObject(list).toString();
			out.write(json);
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@RequestMapping("/deleExchange")
	public void deleExchange(HttpServletRequest request, HttpServletResponse response){
		String exchangeid = request.getParameter("exchangeidArray").toString();
		PrintWriter out;
		try {
			exchangeService.deleExchange(exchangeid);
			out = response.getWriter();
			out.write("true");
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping("/getExchangeMessage")
	public void getExchangeMessage(HttpServletRequest request, HttpServletResponse response){
		Integer exchangeid = Integer.valueOf(request.getParameter("exchangeid"));
		PrintWriter out;
		try {
			ExchangeProviceVO exchange = exchangeService.selectGameByExchangeName(exchangeid);
			out = response.getWriter();
			String json = JSONObject.fromObject(exchange).toString();
			out.write(json);
			out.flush();
			out.close();
		} catch (Exception e) {
		}
	}
	@RequestMapping("/selectExchangeById")
	public String selectExchangeById(HttpServletRequest request, HttpServletResponse response){
		Integer exchangeid = Integer.valueOf(request.getParameter("exchangeId"));
		ExchangeProviceVO exchange;
		try {
			exchange = exchangeService.selectGameByExchangeName(exchangeid);
			request.setAttribute("exchangeDetil", exchange);
		} catch (Exception e) {
		}
		return "/exchange/updateExchange.jsp";
	}
	
	
	@RequestMapping("/updateExchange")
	public void updateConversion(HttpServletRequest request,HttpServletResponse response){
		Integer exchangeId = Integer.parseInt(request.getParameter("exchangeId"));
		Integer exchangeCharge = Integer.parseInt(request.getParameter("exchangeCharge"));
		String exchangeStatus = request.getParameter("exchangeStatus");
		PrintWriter out;
		try {
			exchangeService.updateExchange(exchangeId,exchangeCharge,exchangeStatus);
			out = response.getWriter();
			out.write("true");
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping("/selectExchangeByExchangeName")
	public void selectExchangeByExchangeName(HttpServletRequest request, HttpServletResponse response){
		ModelAndView mv = new ModelAndView();
		String exchangeCity = request.getParameter("exchangeCity");
		Integer exchangeCityid;
		//Integer.valueOf()不能转换null
		if (exchangeCity !=null && exchangeCity != "" ) {
			exchangeCityid = Integer.valueOf(request.getParameter("exchangeCity"));
			}else{
				exchangeCityid = null;
			}
		PrintWriter out;
		try {
			Exchange exchange = exchangeService.selectExchangeByExchangeName(exchangeCity);
			out = response.getWriter();
			if(exchange != null){
				out.write("true");
			}
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@RequestMapping("/addExchange")
	public ModelAndView addExchange(String exchangeCity,Integer exchangeCharge,String exchangeStatus,HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		Exchange exchange = new Exchange();
		exchange.setExchangeCharge(exchangeCharge);
		exchange.setExchangeCityId(Integer.valueOf(exchangeCity));
		exchange.setExchangeStatus(exchangeStatus);
		try {
			exchangeService.addExchange(exchange);
			mv.setViewName("/exchange/exchange.jsp");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mv;
	}
	
	
	
	
	
	
	
}
