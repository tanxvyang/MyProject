package com.ssm.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.pojo.Card;
import com.ssm.pojo.Recharge;
import com.ssm.service.CardService;
import com.ssm.service.RechargeService;
import com.ssm.util.Pager;

@Controller
@RequestMapping("/recharge")
public class RechargeController {
	@Autowired
	private RechargeService rechargeService;
	@RequestMapping("/getRechargeByPager")
	public String getRechargeByPager(HttpServletRequest request,HttpServletResponse response){
		Integer pageNo = Integer.parseInt(request.getParameter("pageNo"));
		String userName = request.getParameter("userName");
		Pager<Recharge> pager = rechargeService.getRechargeByPager(pageNo,userName);
			PrintWriter out;
			try {
				out = response.getWriter();
				String json = JSONObject.fromObject(pager).toString();
				out.write(json);
				out.flush();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return "success";
		}
}
