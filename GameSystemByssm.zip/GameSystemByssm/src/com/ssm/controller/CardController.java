package com.ssm.controller;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssm.exception.AddCardException;
import com.ssm.pojo.vo.CardVOType;
import com.ssm.service.CardService;
import com.ssm.util.Pager;

@Controller
@RequestMapping("/card")
public class CardController {
	
	@Autowired
	private  CardService cardService;
	
	@RequestMapping("/selectAllCard")
	public void selectAllCard(HttpServletRequest request, HttpServletResponse response ){
		Integer pageNo = Integer.valueOf(request.getParameter("pageNo"));
		String cardNumber = request.getParameter("cardNumber");
		String cardStartTime = request.getParameter("cardStartTime");
		String cardEndTime = request.getParameter("cardEndTime");
		String cardCitys =  request.getParameter("cardCity");
		Integer cardCity;
		System.out.println("卡号"+cardNumber);
		System.out.println("开始"+cardStartTime);
		System.out.println("结束"+cardEndTime);
		System.out.println("城市"+cardCitys);
		if (cardCitys !=null && cardCitys != "" ) {
			cardCity = Integer.valueOf(cardCitys);
			}else{
				cardCity = null;
			}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("cardNumber",cardNumber );
		map.put("cardStartTime",cardStartTime );
		map.put("cardEndTime",cardEndTime );
		map.put("cardCity",cardCity );
		map.put("pageNo", pageNo);
		
		try {
			PrintWriter out;
			Pager<CardVOType>  list = cardService.selectAllCard(map);
			System.out.println(list.getList().size());
			out = response.getWriter();
			String json = JSONObject.fromObject(list).toString();
			out.write(json);
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping("/addCard")
	public ModelAndView addCard(Integer num,String[] cardCity,Integer cardAmount,String cardStartTime,String cardEndTime,HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		try {
			if (cardCity.length==0) {
				throw new AddCardException("地区不能为空!");
			}
			for (String string : cardCity) {
				System.out.println(string);
//				Integer cardCityId = Integer.valueOf(string);
			cardService.addCard(num,string,cardAmount,cardStartTime,cardEndTime);
			mv.setViewName("/card/card.jsp");
			}
		} catch (AddCardException e) {
		mv.addObject("isError", true);
		mv.addObject("errorMessage", e.getMessage());
		mv.setViewName("/card/addCard.jsp");
			}
		return mv;
	}
	
	
	
	
	
}
