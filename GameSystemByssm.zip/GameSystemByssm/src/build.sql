--用户表

CREATE TABLE "TANXVYANG"."T_USER" 
   (	"USER_ID" NUMBER, 
	"USER_NAME" VARCHAR2(20 BYTE), 
	"USER_PWD" VARCHAR2(20 BYTE), 
	"USER_PHONE" VARCHAR2(20 BYTE), 
	"USER_CITY" NUMBER, 
	"USER_TARIFFE" NUMBER, 
	"USER_CURRENCY" NUMBER, 
	"USER_CARDAMOUNT" NUMBER, 
	"USER_STATUS" NUMBER, 
	"USERCREATE_TIME" DATE, 
	"USER_SEX" NUMBER, 
	"T_USER_BIRTHDAY" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "TS_TANXVYANG1" ;
--------------------------------------------------------
--  DDL for Table T_USERMANAGER
--------------------------------------------------------
CREATE UNIQUE INDEX "TANXVYANG"."T_USER_PK" ON "TANXVYANG"."T_USER" ("USER_ID") 
CREATE UNIQUE INDEX "TANXVYANG"."T_PROVINCE_PK" ON "TANXVYANG"."T_PROVINCE" ("PROV_ID") 


----------  触发器
--------------------------------------------------------
--  DDL for Trigger USERID_TGR
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "TANXVYANG"."USERID_TGR" 
                before insert on t_user
                for each row --对表的每一行触发器执行一次
                 WHEN (new.user_ID is null) declare
                next_id number;
             begin
                select user_id_seq.nextval into next_id from dual;
                :new.user_ID :=next_id;  --   :new 表示新插入的那条记录 修改即将进入表中user的id值
             end;
/
ALTER TRIGGER "TANXVYANG"."USERID_TGR" ENABLE;
--------------------------------------------------------
--  DDL for Trigger MANAGERID_TGR
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "TANXVYANG"."MANAGERID_TGR" 
                before insert on T_USERMANAGER
                for each row --对表的每一行触发器执行一次
                 WHEN (new.id is null) declare
                next_id number;
             begin
                select MANAGERid_seq2.nextval into next_id from dual;
                :new.id :=next_id;  --   :new 表示新插入的那条记录 修改即将进入表中user的id值
             end;
/
ALTER TRIGGER "TANXVYANG"."MANAGERID_TGR" ENABLE;

-----管理员表


---
  CREATE TABLE "TANXVYANG"."T_USERMANAGER" 
   (	"ID" NUMBER, 
	"ROOT_NAME" VARCHAR2(20 BYTE), 
	"ROOT_PSW" VARCHAR2(20 BYTE), 
	"ROOT_PHONE" VARCHAR2(20 BYTE), 
	"CREATE_TIME" DATE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "TS_TANXVYANG1" ;



 --省份表 t_province
--字段:
--prov_id（省份id）,
--prov_name（省份名）
create or replace  table t_province(
  prov_id number primary key,
  prov_name varchar(20)
);

 create  sequence priovince_id_seq increment by 1 start with 1 nomaxvalue nocycle cache 20;
 --创建触发器
            create or replace trigger priovinceid_tgr
                before insert on t_province
                for each row --对表的每一行触发器执行一次
                when(new.prov_id is null)   --判断条件
            declare
                next_id number;
             begin
                select priovince_id_seq.nextval into next_id from dual;
                :new.prov_id :=next_id;  --   :new 表示新插入的那条记录 修改即将进入表中user的id值
             end;
 
--游戏类型表
CREATE TABLE "TANXVYANG"."T_GAME_TYPE" 
   (	"TYPE_ID" NUMBER NOT NULL ENABLE, 
	"TYPE_NAME" VARCHAR2(20 BYTE), 
	"TYPE_STATUS" VARCHAR2(20 BYTE), 
	"TYPE_PICTURE" VARCHAR2(100 BYTE), 
	"TYPECREATE_TIME" DATE, 
	"TYPEUPDATE_TIME" DATE, 
	 CONSTRAINT "T_GAME_TYPE_PK" PRIMARY KEY ("TYPE_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TS_TANXVYANG1"  ENABLE
   )
--id序列
create  sequence Gameid_seq increment by 1 start with 2 nomaxvalue nocycle cache 20;
--游戏类型id触发器

 create or replace trigger gameid_tgr
                before insert on T_game
                for each row --对表的每一行触发器执行一次
                when(new.game_id is null)   --判断条件
            declare
                next_id number;
             begin
                select gameid_seq.nextval into next_id from dual;
                :new.game_id :=next_id;  --   :new 表示新插入的那条记录 修改即将进入表中user的id值
             end;
     ---数据库转换时间格式        
             select to_char(typeCREATE_TIME,'yyyy-mm-dd hh24:mi:ss') as CREATE_TIME from t_game_type;
             
             
--游戏表
CREATE TABLE "TANXVYANG"."T_GAME" 
   (	"ID" NUMBER(38,0), 
	"GAME_NAME" VARCHAR2(130 BYTE), 
	"GAMETYPE_ID" NUMBER(38,0), 
	"GAMETYPE_NAME" VARCHAR2(100 BYTE), 
	"GAME_IMG" VARCHAR2(120 BYTE), 
	"GAME_DEVELOPER" VARCHAR2(30 BYTE), 
	"GAME_NUMBER" VARCHAR2(100 BYTE), 
	"GAME_TXT" VARCHAR2(100 BYTE), 
	"SCREENSHOT_ONE" VARCHAR2(120 BYTE), 
	"SCREENSHOT_TWO" VARCHAR2(120 BYTE), 
	"SCREENSHOT_THREE" VARCHAR2(120 BYTE), 
	"GAME_DETAILS" VARCHAR2(1000 BYTE), 
	"GAME_SYNOPSIS" VARCHAR2(1000 BYTE), 
	"GAME_STATUS" VARCHAR2(8 BYTE), 
	"GAME_PRICE" NUMBER(38,0), 
	"RMB" NUMBER(38,0), 
	"CREATE_TIME" VARCHAR2(30 BYTE), 
	"UPDATE_TIME" VARCHAR2(30 BYTE)
   ) 
 create  sequence Gameid_seq increment by 1 start with 2 nomaxvalue nocycle cache 20;

 create or replace trigger gameid_tgr
                before insert on T_game
                for each row --对表的每一行触发器执行一次
                when(new.game_id is null)   --判断条件
            declare
                next_id number;
             begin
                select gameid_seq.nextval into next_id from dual;
                :new.game_id :=next_id;  --   :new 表示新插入的那条记录 修改即将进入表中user的id值
             end;



--密保卡表
create  TABLE t_card(
    id number(10),
    card_number varchar2(40),
    card_pwd varchar2(40),
    card_amount number(30),
    cardCity_id number(10),
    cardstart_time varchar2(50),
    cardend_time varchar2(40),
    card_status varchar2(40),
    cardcreate_time date
    
);

create  sequence cardId_seq increment by 1 start with 2 nomaxvalue nocycle cache 20;

 create or replace trigger cardId_tgr
                before insert on t_card
                for each row --对表的每一行触发器执行一次
                when(new.id is null)   --判断条件
            declare
                next_id number;
             begin
                select cardId_seq.nextval into next_id from dual;
                :new.id :=next_id;  --   :new 表示新插入的那条记录 修改即将进入表中的id值
             end;
--用户购买记录
create table t_buydetail(
             id number(16),
             user_id number(16),
             user_name varchar2(23),
             game_name varchar2(23),
             buy_way varchar2(20),
             game_price number(18),
             first_time varchar2(30),
             latest_time varchar2(30),
             download_num number(20)
);
create  sequence buydetailId_seq increment by 1 start with 2 nomaxvalue nocycle cache 20;

 create or replace trigger buydetailId_tgr
                before insert on t_buydetail
                for each row --对表的每一行触发器执行一次
                when(new.id is null)   --判断条件
            declare
                next_id number;
             begin
                select buydetailId_seq.nextval into next_id from dual;
                :new.id :=next_id;  --   :new 表示新插入的那条记录 修改即将进入表中的id值
             end;
             
 --充值记录
create table t_recharge(
    id number,
    user_id number(10),
    user_name varchar2(30),
    card_id number(10),
    card_number varchar2(40),
    card_pwd varchar2(40),
    price varchar2(40),
    end_time varchar2(40)
     
);


create  sequence rechargeId_seq increment by 1 start with 2 nomaxvalue nocycle cache 20;

 create or replace trigger rechargeId_tgr
                before insert on t_recharge
                for each row --对表的每一行触发器执行一次
                when(new.id is null)   --判断条件
            declare
                next_id number;
             begin
                select rechargeId_seq.nextval into next_id from dual;
                :new.id :=next_id;  --   :new 表示新插入的那条记录 修改即将进入表中的id值
             end;            